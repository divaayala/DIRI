# DIRI — *menata diri, bahagia hari ini*

Personal AI stylist & mix-n-match outfit untuk pengguna Indonesia.
PWA (Progressive Web App) yang bisa dipakai dari browser HP & desktop, dan bisa di-install ke home screen.

![DIRI](public/icon-512.png)

## Fitur utama

- **Filter preferensi manual** — onboarding 9-langkah: tinggi/berat, bentuk tubuh, skintone, undertone, gaya, lifestyle, warna favorit, budget, brand favorit.
- **Lemari pribadi** — upload foto baju yang kamu punya, kategorikan (topi/baju/celana/sepatu/tas/aksesoris).
- **Beranda inspirasi** — feed Pinterest-style berisi padu-padan outfit head-to-toe, di-personalize sesuai profil.
- **Kamera Pose Frame** — outline tubuh & frame wajah sesuai bentuk badan kamu (rectangle, hourglass, pear, apple, dst.) plus oval kerudung untuk pengguna hijab.
- **Kamera Try-On** — overlay item dari lemari pribadi atau katalog ke kamera real-time.
- **Pop-up detail produk** — harga, brand, warna, tags.
- **Link checkout eksternal** — langsung membuka pencarian produk di Tokopedia/Shopee/Zalora.
- **Share outfit** — Web Share API untuk kirim foto outfit ke chat/sosmed (atau download PNG).
- **AI stylist chat** — minta saran outfit dengan konteks profil, mendapat respons JSON terstruktur lengkap dengan item-item dari katalog beserta link beli.

## Tech stack

- **Vite** + **React 18** + **TypeScript**
- **Tailwind CSS** untuk styling (palet custom cream/ink/clay)
- **React Router 6** untuk navigasi
- **vite-plugin-pwa** untuk installable PWA + offline caching
- **Anthropic Claude API** (`claude-haiku-4-5`) untuk AI stylist — opsional, fallback rule-based tersedia
- **localStorage** untuk MVP auth, profil, wardrobe, dan chat history
- **Web Crypto API** untuk hash password (SHA-256)
- **Google Fonts** — Fraunces (display) + DM Sans (body)
- **Unsplash** sebagai sumber gambar produk dummy

## Cara menjalankan secara lokal

### Prasyarat
- Node.js 18+ dan npm/pnpm/yarn
- Browser modern (Chrome/Safari/Edge/Firefox)

### Langkah

```bash
# 1. Install dependencies
npm install

# 2. (Opsional) Setup AI stylist
cp .env.example .env.local
# Edit .env.local dan isi VITE_ANTHROPIC_API_KEY=sk-ant-...
# Tanpa step ini, AI stylist akan pakai rule-based fallback.

# 3. Jalankan dev server
npm run dev
```

Buka `http://localhost:5173` di browser. Untuk testing di HP, gunakan IP lokal yang ditampilkan terminal (misalnya `http://192.168.x.x:5173`), pastikan HP & laptop satu jaringan WiFi.

> **Catatan kamera**: getUserMedia (akses kamera) hanya jalan di `localhost` atau HTTPS. Saat dev, pakai `localhost`. Saat deploy, pastikan domain pakai HTTPS (Vercel/Netlify otomatis).

### Build production

```bash
npm run build
npm run preview
```

Output ada di folder `dist/`.

## Mendapatkan Anthropic API key

1. Daftar di [console.anthropic.com](https://console.anthropic.com/).
2. Buka **Settings → API Keys → Create Key**.
3. Salin key (formatnya `sk-ant-...`) ke `.env.local`:
   ```
   VITE_ANTHROPIC_API_KEY=sk-ant-xxxxxx
   ```
4. Restart dev server.

> ⚠️ **Penting**: Pemakaian saat ini memanggil API langsung dari browser. Untuk produksi sungguhan, sebaiknya pindahkan ke backend proxy (Vercel Function / Cloudflare Worker) supaya API key tidak bocor ke client. Untuk MVP/demo, ini cukup.

## Push ke GitHub

Karena project ini diserahkan dalam bentuk ZIP, kamu perlu push sendiri ke GitHub:

```bash
# 1. Extract ZIP dan masuk ke folder
unzip diri.zip
cd diri

# 2. Init git repo
git init
git add .
git commit -m "Initial commit: DIRI v0.1"

# 3. Buat repo baru di github.com (jangan ceklis "Add README" karena sudah ada)
#    Misal nama: candy/diri

# 4. Add remote dan push
git branch -M main
git remote add origin https://github.com/USERNAME/diri.git
git push -u origin main
```

Ganti `USERNAME` dengan username GitHub kamu.

## Deploy gratis ke Vercel

1. Login di [vercel.com](https://vercel.com/) (bisa pakai akun GitHub).
2. Klik **Add New → Project → Import** repo `diri` kamu.
3. Vercel otomatis deteksi sebagai Vite project. Klik **Deploy**.
4. (Opsional) Tambahkan environment variable `VITE_ANTHROPIC_API_KEY` di Vercel project settings sebelum redeploy.
5. Selesai — kamu dapat URL `https://diri-xxx.vercel.app`.

Karena ada `vercel.json` untuk SPA rewrite, semua route React Router akan jalan dengan baik.

## Struktur folder

```
diri/
├── public/                 # PWA icons, favicon, static assets
├── src/
│   ├── components/         # AppShell, Splash, LogoMark
│   ├── context/            # AuthContext (login/register/profile)
│   ├── data/               # Katalog 50 produk dummy
│   ├── lib/                # storage helper, AI service
│   ├── pages/              # Landing, Login, Register, Onboarding,
│   │                       # Home, Search, Camera, Chat, Profile, Wardrobe
│   ├── types/              # TypeScript interfaces
│   ├── App.tsx             # Router & protected routes
│   ├── main.tsx            # Entry point
│   └── index.css           # Tailwind + custom utilities
├── index.html
├── vite.config.ts          # Vite + PWA config
├── tailwind.config.js
├── tsconfig.*.json
├── vercel.json
├── .env.example
├── .gitignore
└── package.json
```

## Arsitektur penting

### Auth & data
- Disimpan **lokal di browser** via `localStorage` (namespace `diri:`).
- Password di-hash pakai SHA-256 (Web Crypto API). Sudah cukup untuk MVP, **bukan** untuk produksi sungguhan — produksi butuh backend auth (Supabase/Firebase/Clerk).
- Data per user: `users`, `session`, `profile:{userId}`, `wardrobe:{userId}`, `chat:{userId}`.

### AI stylist
- Memanggil endpoint `https://api.anthropic.com/v1/messages` langsung dari browser dengan header `anthropic-dangerous-direct-browser-access: true`.
- System prompt memaksa output JSON terstruktur dengan schema `{reply, outfit: {occasion, vibe, items[], stylingNotes}}`.
- Pesan user dikirim bersama profil + katalog ringkas (id|category|name|brand|harga|warna|tags).
- Untuk user kerudung, katalog di-filter dulu (modest items diprioritaskan, crop top & short pants disisihkan).
- Fallback rule-based aktif jika tidak ada API key atau API gagal — mendeteksi keyword acara (kantor, kemerdekaan, kondangan, nongkrong, date, olahraga) lalu pick item dari katalog by tag.

### Kamera
- Pakai `navigator.mediaDevices.getUserMedia` standar.
- Pose Frame: SVG overlay dengan siluet tubuh yang **berubah sesuai bodyType** (shoulder/waist/hip ratio berbeda per tipe) + lingkaran wajah (atau oval kerudung untuk hijabi).
- Try-On: overlay `<img>` di tengah feed kamera, lalu di-composite ke canvas saat capture.
- Foto selfie otomatis di-mirror (untuk yang pakai facingMode user).
- Share via Web Share API, fallback download PNG.

## Catatan & next steps

Ini MVP. Untuk diproduksi-kan:
1. **Backend auth & database** — pindahkan dari localStorage ke Supabase/Firebase + RLS supaya data sinkron antar device.
2. **AI proxy** — taruh API key di server (Vercel Function) supaya tidak bocor.
3. **Katalog asli** — partneran dengan brand lokal atau scrape katalog real, pakai affiliate link untuk monetisasi.
4. **Body detection beneran** — MediaPipe Pose / TensorFlow.js BlazePose untuk overlay yang benar-benar nempel di tubuh real-time (sekarang masih guide statis).
5. **Try-on AR proper** — virtual try-on dengan diffusion model (mis. CatVTON, IDM-VTON) untuk hasil yang fotografis.
6. **Notifikasi & jadwal** — daily outfit suggestion berdasarkan cuaca & kalender.

## Lisensi

MIT — bebas modifikasi & komersial.

---

Dibuat dengan ❤️ untuk personal style yang lebih percaya diri.
