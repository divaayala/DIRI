import type { Product } from '@/types'

// Marketplace search URL builders — opens real product search on the marketplace
export function buildMarketplaceUrl(p: Product): string {
  const q = encodeURIComponent(p.searchQuery)
  switch (p.marketplace) {
    case 'tokopedia':
      return `https://www.tokopedia.com/search?st=product&q=${q}`
    case 'shopee':
      return `https://shopee.co.id/search?keyword=${q}`
    case 'zalora':
      return `https://www.zalora.co.id/search?q=${q}`
  }
}

// Unsplash image helper with consistent sizing
const img = (id: string) => `https://images.unsplash.com/photo-${id}?w=600&q=80&auto=format&fit=crop`

export const PRODUCTS: Product[] = [
  // ATASAN — kaos / kemeja
  { id: 'p001', name: 'Kaos Oversized Cotton Basic', brand: 'Erigo', category: 'atasan', price: 119000, currency: 'IDR', imageUrl: img('1521572163474-6864f9cf17ab'), colors: ['putih', 'hitam', 'krem'], tags: ['kasual', 'streetwear', 'basic'], marketplace: 'tokopedia', searchQuery: 'erigo kaos oversized cotton' },
  { id: 'p002', name: 'Kemeja Linen Lengan Panjang', brand: 'Uniqlo', category: 'atasan', price: 399000, currency: 'IDR', imageUrl: img('1602810318383-e386cc2a3ccf'), colors: ['putih', 'biru muda', 'beige'], tags: ['smart-casual', 'kantor', 'minimalis'], marketplace: 'zalora', searchQuery: 'uniqlo kemeja linen' },
  { id: 'p003', name: 'Polo Shirt Pique Slim Fit', brand: 'Lacoste', category: 'atasan', price: 850000, currency: 'IDR', imageUrl: img('1586790170083-2f9ceadc732d'), colors: ['navy', 'putih', 'hijau'], tags: ['smart-casual', 'klasik'], marketplace: 'zalora', searchQuery: 'lacoste polo pique' },
  { id: 'p004', name: 'Blouse Satin Lengan Pendek', brand: 'Cotton On', category: 'atasan', price: 299000, currency: 'IDR', imageUrl: img('1485518882345-15568b007407'), colors: ['hitam', 'champagne', 'merah marun'], tags: ['feminin', 'kantor', 'formal'], marketplace: 'zalora', searchQuery: 'cotton on blouse satin' },
  { id: 'p005', name: 'T-Shirt Graphic Streetwear', brand: 'Thanks Insomnia', category: 'atasan', price: 249000, currency: 'IDR', imageUrl: img('1503341504253-dff4815485f1'), colors: ['hitam', 'putih', 'cokelat'], tags: ['streetwear', 'kasual', 'tren'], marketplace: 'tokopedia', searchQuery: 'thanks insomnia tshirt' },
  { id: 'p006', name: 'Tunik Katun Premium', brand: 'Hijup', category: 'atasan', price: 350000, currency: 'IDR', imageUrl: img('1610030469983-98e550d6193c'), colors: ['mocca', 'navy', 'sage'], tags: ['modest', 'kerudung', 'kantor'], marketplace: 'tokopedia', searchQuery: 'hijup tunik katun' },
  { id: 'p007', name: 'Crop Top Rib Knit', brand: 'Pull&Bear', category: 'atasan', price: 199000, currency: 'IDR', imageUrl: img('1571513722275-4b41940f54b8'), colors: ['hitam', 'putih', 'pink'], tags: ['tren', 'kasual', 'feminin'], marketplace: 'zalora', searchQuery: 'pull and bear crop top rib' },
  { id: 'p008', name: 'Henley Long Sleeve', brand: 'H&M', category: 'atasan', price: 299000, currency: 'IDR', imageUrl: img('1620799140408-edc6dcb6d633'), colors: ['krem', 'hitam', 'olive'], tags: ['kasual', 'minimalis'], marketplace: 'zalora', searchQuery: 'hm henley long sleeve' },

  // OUTER — jacket / cardigan
  { id: 'p009', name: 'Blazer Oversized Wool Blend', brand: 'Zara', category: 'outer', price: 899000, currency: 'IDR', imageUrl: img('1591047139829-d91aecb6caea'), colors: ['hitam', 'cokelat', 'abu'], tags: ['kantor', 'formal', 'smart-casual'], marketplace: 'zalora', searchQuery: 'zara blazer oversized wool' },
  { id: 'p010', name: 'Denim Jacket Trucker', brand: 'Levis', category: 'outer', price: 999000, currency: 'IDR', imageUrl: img('1543076447-215ad9ba6923'), colors: ['biru wash', 'hitam'], tags: ['kasual', 'klasik', 'streetwear'], marketplace: 'zalora', searchQuery: 'levis denim jacket trucker' },
  { id: 'p011', name: 'Hoodie Fleece Premium', brand: 'Champion', category: 'outer', price: 599000, currency: 'IDR', imageUrl: img('1556821840-3a63f95609a7'), colors: ['abu', 'hitam', 'navy'], tags: ['streetwear', 'kasual', 'nyaman'], marketplace: 'tokopedia', searchQuery: 'champion hoodie fleece' },
  { id: 'p012', name: 'Cardigan Knit Cropped', brand: 'Stradivarius', category: 'outer', price: 399000, currency: 'IDR', imageUrl: img('1434389677669-e08b4cac3105'), colors: ['krem', 'pink dusty', 'hitam'], tags: ['feminin', 'tren', 'layering'], marketplace: 'zalora', searchQuery: 'stradivarius cardigan knit cropped' },
  { id: 'p013', name: 'Bomber Jacket Nylon', brand: 'Uniqlo', category: 'outer', price: 599000, currency: 'IDR', imageUrl: img('1591047139756-eaedf9bce05f'), colors: ['hitam', 'olive', 'navy'], tags: ['streetwear', 'kasual', 'tren'], marketplace: 'zalora', searchQuery: 'uniqlo bomber jacket' },
  { id: 'p014', name: 'Trench Coat Klasik', brand: 'Massimo Dutti', category: 'outer', price: 2499000, currency: 'IDR', imageUrl: img('1539533018447-63fcce2678e3'), colors: ['camel', 'navy', 'hitam'], tags: ['formal', 'klasik', 'mewah'], marketplace: 'zalora', searchQuery: 'massimo dutti trench coat' },
  { id: 'p015', name: 'Cardigan Outer Panjang Modest', brand: 'Buttonscarves', category: 'outer', price: 450000, currency: 'IDR', imageUrl: img('1591369822096-ffd140ec948f'), colors: ['mocca', 'hitam', 'dusty pink'], tags: ['modest', 'kerudung', 'feminin'], marketplace: 'tokopedia', searchQuery: 'buttonscarves outer panjang' },

  // BAWAHAN — celana / rok
  { id: 'p016', name: 'Wide Leg Pants Linen', brand: 'Cotton Ink', category: 'bawahan', price: 459000, currency: 'IDR', imageUrl: img('1594633312681-425c7b97ccd1'), colors: ['krem', 'hitam', 'cokelat'], tags: ['smart-casual', 'feminin', 'nyaman'], marketplace: 'tokopedia', searchQuery: 'cotton ink wide leg linen pants' },
  { id: 'p017', name: 'Jeans Slim Fit Stretch', brand: 'Levis 511', category: 'bawahan', price: 899000, currency: 'IDR', imageUrl: img('1542272604-787c3835535d'), colors: ['biru tua', 'biru wash', 'hitam'], tags: ['kasual', 'klasik', 'serbaguna'], marketplace: 'zalora', searchQuery: 'levis 511 slim fit jeans' },
  { id: 'p018', name: 'Chino Pants Tapered', brand: 'Uniqlo', category: 'bawahan', price: 399000, currency: 'IDR', imageUrl: img('1473966968600-fa801b80a8af'), colors: ['beige', 'olive', 'navy'], tags: ['smart-casual', 'kantor', 'serbaguna'], marketplace: 'zalora', searchQuery: 'uniqlo chino pants tapered' },
  { id: 'p019', name: 'Cargo Pants Loose Fit', brand: 'Pull&Bear', category: 'bawahan', price: 499000, currency: 'IDR', imageUrl: img('1624378439575-d8705ad7ae80'), colors: ['olive', 'hitam', 'krem'], tags: ['streetwear', 'tren', 'kasual'], marketplace: 'zalora', searchQuery: 'pull and bear cargo pants loose' },
  { id: 'p020', name: 'Rok Plisket Midi', brand: 'Shopatvelvet', category: 'bawahan', price: 350000, currency: 'IDR', imageUrl: img('1583496661160-fb5886a13d44'), colors: ['hitam', 'mocca', 'navy'], tags: ['feminin', 'kantor', 'modest'], marketplace: 'tokopedia', searchQuery: 'shopatvelvet rok plisket midi' },
  { id: 'p021', name: 'Celana Kulot Modest', brand: 'Heaven Lights', category: 'bawahan', price: 285000, currency: 'IDR', imageUrl: img('1551803091-e20673f15770'), colors: ['hitam', 'mocca', 'sage'], tags: ['modest', 'kerudung', 'nyaman'], marketplace: 'tokopedia', searchQuery: 'heaven lights celana kulot' },
  { id: 'p022', name: 'Tailored Trousers Pleated', brand: 'Zara', category: 'bawahan', price: 699000, currency: 'IDR', imageUrl: img('1506629082955-511b1aa562c8'), colors: ['hitam', 'abu', 'cokelat'], tags: ['formal', 'kantor', 'smart-casual'], marketplace: 'zalora', searchQuery: 'zara tailored trousers pleated' },
  { id: 'p023', name: 'Short Pants Denim', brand: 'Bershka', category: 'bawahan', price: 299000, currency: 'IDR', imageUrl: img('1591195853828-11db59a44f6b'), colors: ['biru wash', 'hitam', 'putih'], tags: ['kasual', 'kasual'], marketplace: 'zalora', searchQuery: 'bershka short pants denim' },

  // SEPATU
  { id: 'p024', name: 'Sneakers Court Classic', brand: 'Adidas Stan Smith', category: 'sepatu', price: 1299000, currency: 'IDR', imageUrl: img('1542291026-7eec264c27ff'), colors: ['putih', 'putih-hijau'], tags: ['klasik', 'serbaguna', 'kasual'], marketplace: 'zalora', searchQuery: 'adidas stan smith' },
  { id: 'p025', name: 'Sneakers Chunky Sole', brand: 'New Balance 530', category: 'sepatu', price: 1899000, currency: 'IDR', imageUrl: img('1539185441755-769473a23570'), colors: ['putih-perak', 'krem'], tags: ['tren', 'streetwear'], marketplace: 'zalora', searchQuery: 'new balance 530' },
  { id: 'p026', name: 'Loafer Kulit Klasik', brand: 'Buttero', category: 'sepatu', price: 1599000, currency: 'IDR', imageUrl: img('1533867617858-e7b97e060509'), colors: ['cokelat', 'hitam'], tags: ['smart-casual', 'kantor', 'klasik'], marketplace: 'zalora', searchQuery: 'loafer kulit pria klasik' },
  { id: 'p027', name: 'Heels Mules Pointed', brand: 'Charles & Keith', category: 'sepatu', price: 699000, currency: 'IDR', imageUrl: img('1543163521-1bf539c55dd2'), colors: ['hitam', 'nude', 'cokelat'], tags: ['feminin', 'kantor', 'formal'], marketplace: 'zalora', searchQuery: 'charles and keith heels mules' },
  { id: 'p028', name: 'Flat Shoes Ballerina', brand: 'Vincci', category: 'sepatu', price: 399000, currency: 'IDR', imageUrl: img('1518049362265-d5b2a6b00b37'), colors: ['hitam', 'nude', 'merah'], tags: ['feminin', 'nyaman'], marketplace: 'zalora', searchQuery: 'vincci flat shoes ballerina' },
  { id: 'p029', name: 'Boots Chelsea Kulit', brand: 'Dr Martens', category: 'sepatu', price: 2599000, currency: 'IDR', imageUrl: img('1608256246200-53e635b5b65f'), colors: ['hitam', 'cokelat'], tags: ['streetwear', 'klasik', 'edgy'], marketplace: 'zalora', searchQuery: 'dr martens chelsea boots' },
  { id: 'p030', name: 'Sandal Slide Cushion', brand: 'Birkenstock', category: 'sepatu', price: 999000, currency: 'IDR', imageUrl: img('1603487742131-4160ec999306'), colors: ['cokelat', 'hitam', 'putih'], tags: ['kasual', 'nyaman'], marketplace: 'zalora', searchQuery: 'birkenstock arizona' },

  // TAS
  { id: 'p031', name: 'Tote Bag Canvas Premium', brand: 'Baggu', category: 'tas', price: 599000, currency: 'IDR', imageUrl: img('1584917865442-de89df76afd3'), colors: ['krem', 'hitam', 'navy'], tags: ['kasual', 'minimalis'], marketplace: 'zalora', searchQuery: 'baggu tote bag canvas' },
  { id: 'p032', name: 'Sling Bag Crossbody Mini', brand: 'Pedro', category: 'tas', price: 899000, currency: 'IDR', imageUrl: img('1548036328-c9fa89d128fa'), colors: ['hitam', 'cokelat', 'putih'], tags: ['serbaguna', 'tren'], marketplace: 'zalora', searchQuery: 'pedro sling bag crossbody' },
  { id: 'p033', name: 'Backpack Daypack Minimalis', brand: 'Bagspack', category: 'tas', price: 459000, currency: 'IDR', imageUrl: img('1553062407-98eeb64c6a62'), colors: ['hitam', 'olive', 'navy'], tags: ['kasual', 'fungsional'], marketplace: 'tokopedia', searchQuery: 'bagspack backpack daypack' },
  { id: 'p034', name: 'Shoulder Bag Hobo Leather', brand: 'Charles & Keith', category: 'tas', price: 799000, currency: 'IDR', imageUrl: img('1591561954557-26941169b49e'), colors: ['cokelat', 'hitam', 'krem'], tags: ['feminin', 'klasik'], marketplace: 'zalora', searchQuery: 'charles and keith shoulder bag hobo' },
  { id: 'p035', name: 'Briefcase Slim Kulit', brand: 'Massimo Dutti', category: 'tas', price: 1999000, currency: 'IDR', imageUrl: img('1547949003-9792a18a2601'), colors: ['cokelat', 'hitam'], tags: ['formal', 'kantor', 'klasik'], marketplace: 'zalora', searchQuery: 'massimo dutti briefcase kulit' },

  // TOPI
  { id: 'p036', name: 'Bucket Hat Canvas', brand: 'Stussy', category: 'topi', price: 599000, currency: 'IDR', imageUrl: img('1556306535-0f09a537f0a3'), colors: ['hitam', 'krem', 'navy'], tags: ['streetwear', 'tren'], marketplace: 'tokopedia', searchQuery: 'stussy bucket hat' },
  { id: 'p037', name: 'Baseball Cap Dad Hat', brand: 'New Era', category: 'topi', price: 399000, currency: 'IDR', imageUrl: img('1588850561407-ed78c282e89b'), colors: ['hitam', 'krem', 'navy', 'olive'], tags: ['kasual', 'streetwear'], marketplace: 'zalora', searchQuery: 'new era dad hat' },
  { id: 'p038', name: 'Beanie Rib Knit', brand: 'Carhartt', category: 'topi', price: 299000, currency: 'IDR', imageUrl: img('1576871337622-98d48d1cf531'), colors: ['hitam', 'krem', 'cokelat'], tags: ['streetwear', 'kasual'], marketplace: 'tokopedia', searchQuery: 'carhartt beanie knit' },

  // AKSESORIS — kerudung, kacamata, jam, ikat pinggang
  { id: 'p039', name: 'Kerudung Pashmina Crinkle', brand: 'Buttonscarves', category: 'aksesoris', price: 199000, currency: 'IDR', imageUrl: img('1611042553484-d61f84d22784'), colors: ['mocca', 'dusty pink', 'sage', 'hitam'], tags: ['modest', 'kerudung', 'feminin'], marketplace: 'tokopedia', searchQuery: 'buttonscarves pashmina crinkle' },
  { id: 'p040', name: 'Kerudung Segiempat Voal', brand: 'Vanilla Hijab', category: 'aksesoris', price: 89000, currency: 'IDR', imageUrl: img('1592987680571-faa39bd2532b'), colors: ['putih', 'krem', 'dusty pink', 'navy'], tags: ['modest', 'kerudung', 'formal'], marketplace: 'tokopedia', searchQuery: 'vanilla hijab segiempat voal' },
  { id: 'p041', name: 'Kacamata Aviator Klasik', brand: 'Rayban', category: 'aksesoris', price: 1899000, currency: 'IDR', imageUrl: img('1572635196237-14b3f281503f'), colors: ['gold', 'silver', 'hitam'], tags: ['klasik', 'tren'], marketplace: 'zalora', searchQuery: 'rayban aviator' },
  { id: 'p042', name: 'Jam Tangan Minimalis', brand: 'Daniel Wellington', category: 'aksesoris', price: 1599000, currency: 'IDR', imageUrl: img('1523275335684-37898b6baf30'), colors: ['rosegold', 'silver', 'hitam'], tags: ['minimalis', 'klasik'], marketplace: 'zalora', searchQuery: 'daniel wellington classic' },
  { id: 'p043', name: 'Ikat Pinggang Kulit', brand: 'Coach', category: 'aksesoris', price: 1499000, currency: 'IDR', imageUrl: img('1624222247344-550fb60583dc'), colors: ['cokelat', 'hitam'], tags: ['klasik', 'formal'], marketplace: 'zalora', searchQuery: 'coach belt kulit' },
  { id: 'p044', name: 'Kalung Gold Plated Layered', brand: 'Mejuri', category: 'aksesoris', price: 799000, currency: 'IDR', imageUrl: img('1599643477877-530eb83abc8e'), colors: ['gold'], tags: ['feminin', 'minimalis', 'tren'], marketplace: 'zalora', searchQuery: 'mejuri kalung gold layered' },
  { id: 'p045', name: 'Anting Hoop Mini', brand: 'Pandora', category: 'aksesoris', price: 999000, currency: 'IDR', imageUrl: img('1535632066274-65f9d04e76d6'), colors: ['silver', 'gold'], tags: ['minimalis', 'klasik'], marketplace: 'zalora', searchQuery: 'pandora hoop earring' },

  // EXTRA — local brand IDN streetwear
  { id: 'p046', name: 'Sweater Crewneck Heavyweight', brand: 'Maternal Disaster', category: 'outer', price: 459000, currency: 'IDR', imageUrl: img('1620799140404-77f43c4d33b6'), colors: ['hitam', 'cokelat', 'putih'], tags: ['streetwear', 'kasual'], marketplace: 'tokopedia', searchQuery: 'maternal disaster sweater crewneck' },
  { id: 'p047', name: 'Long Dress Modest Plisket', brand: 'Wearing Klamby', category: 'atasan', price: 750000, currency: 'IDR', imageUrl: img('1572804013427-4d7ca7268217'), colors: ['mocca', 'navy', 'sage'], tags: ['modest', 'kerudung', 'formal'], marketplace: 'tokopedia', searchQuery: 'wearing klamby dress plisket' },
  { id: 'p048', name: 'Polo Knit Short Sleeve', brand: 'COS', category: 'atasan', price: 799000, currency: 'IDR', imageUrl: img('1564859228273-274232fdb516'), colors: ['krem', 'hitam', 'cokelat'], tags: ['minimalis', 'smart-casual'], marketplace: 'zalora', searchQuery: 'cos polo knit' },
  { id: 'p049', name: 'Mom Jeans High Waist', brand: 'H&M', category: 'bawahan', price: 399000, currency: 'IDR', imageUrl: img('1582418702059-97ebafb35d09'), colors: ['biru wash', 'hitam'], tags: ['feminin', 'tren', 'kasual'], marketplace: 'zalora', searchQuery: 'hm mom jeans high waist' },
  { id: 'p050', name: 'Sneakers Low Profile Suede', brand: 'Onitsuka Tiger', category: 'sepatu', price: 1299000, currency: 'IDR', imageUrl: img('1595950653106-6c9ebd614d3a'), colors: ['krem-merah', 'hitam', 'putih'], tags: ['klasik', 'serbaguna', 'tren'], marketplace: 'zalora', searchQuery: 'onitsuka tiger mexico 66' }
]

export function findProductsByTags(tags: string[], category?: Product['category'], limit = 10): Product[] {
  const tagSet = new Set(tags.map(t => t.toLowerCase()))
  return PRODUCTS
    .filter(p => !category || p.category === category)
    .map(p => ({
      product: p,
      score: p.tags.filter(t => tagSet.has(t.toLowerCase())).length
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(x => x.product)
}

export function findProductById(id: string): Product | undefined {
  return PRODUCTS.find(p => p.id === id)
}

export function formatRupiah(n: number): string {
  return 'Rp ' + n.toLocaleString('id-ID')
}
