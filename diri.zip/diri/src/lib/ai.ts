import type { UserProfile, OutfitRecommendation, Product } from '@/types'
import { PRODUCTS, findProductsByTags } from '@/data/products'

// Reads from Vite env. User must set VITE_ANTHROPIC_API_KEY in .env.local
const API_KEY = (import.meta as any).env?.VITE_ANTHROPIC_API_KEY as string | undefined
const MODEL = 'claude-haiku-4-5-20251001'

export function hasApiKey(): boolean {
  return !!API_KEY && API_KEY.length > 10
}

function profileSummary(p: UserProfile): string {
  const parts: string[] = []
  if (p.gender) parts.push(`gender: ${p.gender}`)
  if (p.age) parts.push(`usia: ${p.age}`)
  if (p.heightCm) parts.push(`tinggi: ${p.heightCm}cm`)
  if (p.weightKg) parts.push(`berat: ${p.weightKg}kg`)
  if (p.bodyType) parts.push(`bentuk tubuh: ${p.bodyType}`)
  if (p.skintone) parts.push(`skintone: ${p.skintone}`)
  if (p.undertone) parts.push(`undertone: ${p.undertone}`)
  if (p.headStyle) parts.push(`head style: ${p.headStyle}`)
  if (p.stylePreferences.length) parts.push(`style: ${p.stylePreferences.join(', ')}`)
  if (p.lifestylePreferences.length) parts.push(`lifestyle: ${p.lifestylePreferences.join(', ')}`)
  if (p.colorPreferences.length) parts.push(`warna favorit: ${p.colorPreferences.join(', ')}`)
  if (p.budget) parts.push(`budget: ${p.budget}`)
  if (p.preferredBrands.length) parts.push(`brand favorit: ${p.preferredBrands.join(', ')}`)
  if (p.occupationOrLifestyle) parts.push(`profesi/lifestyle: ${p.occupationOrLifestyle}`)
  return parts.join('; ') || 'profil belum diisi'
}

function profileGaps(p: UserProfile): string[] {
  const gaps: string[] = []
  if (!p.bodyType) gaps.push('bentuk tubuh')
  if (!p.skintone) gaps.push('skintone')
  if (!p.undertone) gaps.push('undertone')
  if (!p.stylePreferences.length) gaps.push('preferensi style')
  if (!p.colorPreferences.length) gaps.push('preferensi warna')
  if (!p.budget) gaps.push('budget')
  if (!p.heightCm || !p.weightKg) gaps.push('tinggi & berat badan')
  return gaps
}

const SYSTEM_PROMPT = `Kamu adalah stylist personal di aplikasi DIRI. Tagline: "menata diri, bahagia hari ini".

Tugas: bantu user padu-padan outfit (mix & match) lengkap dari kepala sampai kaki, berdasarkan profil personal mereka dan acara yang ditanyakan.

Aturan respons:
1. SELALU balas dengan JSON murni — TANPA markdown fence (jangan pakai \`\`\`json), TANPA penjelasan di luar JSON.
2. Format JSON:
{
  "reply": "balasan singkat dan personal dalam bahasa Indonesia kasual (1-3 kalimat) yang menjelaskan vibe outfit yang direkomendasikan",
  "outfit": {
    "occasion": "nama acara/konteks singkat",
    "vibe": "deskripsi vibe outfit (1 kalimat)",
    "items": [
      {"role": "topi" | "atasan" | "outer" | "bawahan" | "sepatu" | "tas" | "aksesoris", "productId": "pXXX dari katalog atau null jika tidak ada", "description": "deskripsi item (warna, style, alasan cocok untuk user)"}
    ],
    "stylingNotes": "tips styling/grooming tambahan (1-3 kalimat)"
  }
}
3. Outfit WAJIB lengkap head-to-toe minimal: atasan + bawahan + sepatu. Tambahkan outer/tas/aksesoris jika sesuai konteks.
4. Untuk user yang pakai kerudung/hijab, WAJIB sertakan kerudung di "role: aksesoris" dan utamakan modest items (rok panjang, tunik, kulot, outer panjang).
5. Pilih productId HANYA dari katalog yang diberikan. Jika tidak ada yang pas, set productId = null dan deskripsikan item idealnya.
6. Pertimbangkan undertone untuk saran warna (warm → krem, mocca, olive, mustard; cool → navy, abu, dusty pink, hitam; neutral → fleksibel).
7. Pertimbangkan body type untuk saran siluet (rectangle → tambah dimensi dengan layering; hourglass → fitted; pear → emphasize atasan; apple → flowy & V-neck; inverted-triangle → bawahan lebih volume; athletic/slim/plus → siluet yang flattering).
8. Hormati budget: hemat (<300rb), menengah (300rb-1jt), premium (1-3jt), mewah (>3jt) per item.
9. Bahasa Indonesia, santai tapi informatif. Tidak boleh pakai emoji.`

interface AIResponse {
  reply: string
  outfit?: OutfitRecommendation
}

function catalogForPrompt(profile: UserProfile): string {
  // Filter katalog kasar berdasarkan kerudung/no
  let filtered = PRODUCTS
  if (profile.headStyle === 'kerudung') {
    // prioritize modest-tagged + exclude crop top, short pants
    filtered = PRODUCTS.filter(p =>
      !p.tags.includes('crop') &&
      !(p.category === 'bawahan' && p.name.toLowerCase().includes('short'))
    )
  }
  return filtered.map(p =>
    `${p.id}|${p.category}|${p.name}|${p.brand}|Rp${p.price}|${p.colors.join('/')}|${p.tags.join(',')}`
  ).join('\n')
}

export async function askStylist(
  userMessage: string,
  profile: UserProfile,
  history: Array<{ role: 'user' | 'assistant'; content: string }>
): Promise<AIResponse & { profileWarnings?: string[] }> {
  const warnings = profileGaps(profile)
  const profileText = profileSummary(profile)
  const catalogText = catalogForPrompt(profile)

  if (!hasApiKey()) {
    // Local rule-based fallback
    return localStylistFallback(userMessage, profile, warnings)
  }

  const messages: Array<{ role: 'user' | 'assistant'; content: string }> = [
    ...history.slice(-8).map(h => ({ role: h.role, content: h.content })),
    {
      role: 'user',
      content: `PROFIL USER: ${profileText}\n\nKATALOG PRODUK YANG TERSEDIA (id|kategori|nama|brand|harga|warna|tags):\n${catalogText}\n\nPERTANYAAN USER: ${userMessage}`
    }
  ]

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY!,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1500,
        system: SYSTEM_PROMPT,
        messages
      })
    })

    if (!res.ok) {
      const errText = await res.text().catch(() => '')
      console.error('Anthropic API error:', res.status, errText)
      return localStylistFallback(userMessage, profile, warnings)
    }

    const data = await res.json()
    const text: string = data.content?.[0]?.text ?? ''
    // strip any ``` fences just in case
    const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim()
    const parsed = JSON.parse(cleaned)
    return {
      reply: parsed.reply,
      outfit: parsed.outfit,
      profileWarnings: warnings.length ? warnings : undefined
    }
  } catch (err) {
    console.error('Stylist error:', err)
    return localStylistFallback(userMessage, profile, warnings)
  }
}

// Fallback ketika tidak ada API key atau API gagal
function localStylistFallback(
  userMessage: string,
  profile: UserProfile,
  warnings: string[]
): AIResponse & { profileWarnings?: string[] } {
  const msg = userMessage.toLowerCase()
  const isModest = profile.headStyle === 'kerudung'

  // Detect occasion roughly
  let occasion = 'aktivitas harian'
  let tags: string[] = ['kasual']
  if (msg.includes('kantor') || msg.includes('kerja') || msg.includes('meeting')) {
    occasion = 'ke kantor / meeting'
    tags = ['kantor', 'smart-casual', 'formal']
  } else if (msg.includes('kemerdekaan') || msg.includes('17 agustus') || msg.includes('merah putih')) {
    occasion = 'tema kemerdekaan'
    tags = ['formal', 'smart-casual']
  } else if (msg.includes('kondangan') || msg.includes('nikahan') || msg.includes('wedding')) {
    occasion = 'kondangan'
    tags = ['formal', 'feminin']
  } else if (msg.includes('nongkrong') || msg.includes('cafe') || msg.includes('hangout')) {
    occasion = 'nongkrong / hangout'
    tags = ['kasual', 'tren', 'streetwear']
  } else if (msg.includes('date') || msg.includes('kencan')) {
    occasion = 'kencan'
    tags = ['feminin', 'smart-casual']
  } else if (msg.includes('olahraga') || msg.includes('gym')) {
    occasion = 'olahraga'
    tags = ['kasual', 'nyaman']
  }

  function pick(category: Product['category'], extraTag?: string): Product | undefined {
    const combined = extraTag ? [...tags, extraTag] : tags
    let candidates = findProductsByTags(combined, category, 20)
    if (isModest) candidates = candidates.filter(c => !c.name.toLowerCase().includes('crop'))
    return candidates[0] ?? PRODUCTS.find(p => p.category === category)
  }

  const items: OutfitRecommendation['items'] = []

  if (isModest) {
    const hijab = pick('aksesoris', 'kerudung')
    if (hijab) items.push({ role: 'aksesoris', productId: hijab.id, description: `${hijab.name} warna netral untuk balance dengan outfit utama.` })
  }

  const atasan = isModest
    ? PRODUCTS.find(p => p.id === 'p006') ?? pick('atasan')
    : pick('atasan')
  if (atasan) items.push({ role: 'atasan', productId: atasan.id, description: `${atasan.name} — pas untuk ${occasion}.` })

  const bawahan = isModest
    ? PRODUCTS.find(p => p.id === 'p021') ?? pick('bawahan')
    : pick('bawahan')
  if (bawahan) items.push({ role: 'bawahan', productId: bawahan.id, description: `${bawahan.name} — siluet yang flattering.` })

  const sepatu = pick('sepatu')
  if (sepatu) items.push({ role: 'sepatu', productId: sepatu.id, description: `${sepatu.name} sebagai finishing touch.` })

  const tas = pick('tas')
  if (tas) items.push({ role: 'tas', productId: tas.id, description: `${tas.name} untuk melengkapi look.` })

  return {
    reply: `Untuk ${occasion}, aku rekomendasiin look yang ${tags[0]} tapi tetap nyaman. Kombinasinya udah aku pertimbangkan dari profil kamu.`,
    outfit: {
      occasion,
      vibe: `${tags.join(', ')} yang effortless`,
      items,
      stylingNotes:
        'Pastikan ukuran pas di badan — bukan terlalu ketat atau terlalu longgar. Untuk acara semi-formal, masukkan atasan ke dalam celana untuk siluet lebih rapi.',
      profileWarnings: warnings.length ? warnings : undefined
    },
    profileWarnings: warnings.length ? warnings : undefined
  }
}
