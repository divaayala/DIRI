export interface User {
  id: string
  email: string
  name: string
  createdAt: string
}

export type Gender = 'pria' | 'wanita' | 'lainnya'
export type BodyType =
  | 'rectangle'
  | 'hourglass'
  | 'pear'
  | 'apple'
  | 'inverted-triangle'
  | 'athletic'
  | 'slim'
  | 'plus'
export type Skintone = 'sangat-terang' | 'terang' | 'sedang' | 'sawo-matang' | 'gelap'
export type Undertone = 'warm' | 'cool' | 'neutral'
export type HeadStyle = 'rambut-pendek' | 'rambut-panjang' | 'kerudung' | 'topi'
export type Budget = 'hemat' | 'menengah' | 'premium' | 'mewah'

export interface UserProfile {
  gender: Gender | null
  age: number | null
  heightCm: number | null
  weightKg: number | null
  bodyType: BodyType | null
  skintone: Skintone | null
  undertone: Undertone | null
  headStyle: HeadStyle | null
  stylePreferences: string[]
  lifestylePreferences: string[]
  colorPreferences: string[]
  budget: Budget | null
  preferredBrands: string[]
  occupationOrLifestyle: string
  completed: boolean
}

export type WardrobeCategory = 'topi' | 'baju' | 'tas' | 'celana' | 'sepatu' | 'aksesoris'

export interface WardrobeItem {
  id: string
  category: WardrobeCategory
  imageDataUrl: string
  label: string
  color?: string
  createdAt: string
}

export type ProductCategory = 'topi' | 'atasan' | 'outer' | 'bawahan' | 'sepatu' | 'tas' | 'aksesoris'

export interface Product {
  id: string
  name: string
  brand: string
  category: ProductCategory
  price: number
  currency: 'IDR'
  imageUrl: string
  colors: string[]
  tags: string[]
  marketplace: 'tokopedia' | 'shopee' | 'zalora'
  // search query for marketplace (since no real product link)
  searchQuery: string
}

export interface OutfitRecommendation {
  occasion: string
  vibe: string
  items: Array<{
    role: 'topi' | 'atasan' | 'outer' | 'bawahan' | 'sepatu' | 'tas' | 'aksesoris'
    productId?: string
    description: string
  }>
  stylingNotes: string
  profileWarnings?: string[]
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  outfit?: OutfitRecommendation
  timestamp: string
}
