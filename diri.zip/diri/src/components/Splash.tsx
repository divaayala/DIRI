import type { CSSProperties } from 'react'

export function LogoMark({ size = 40, color = '#1a1a1a' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M14 10 L14 54 L34 54 C46 54 54 45 54 32 C54 19 46 10 34 10 Z M22 18 L34 18 C41 18 46 24 46 32 C46 40 41 46 34 46 L22 46 Z"
        fill={color}
      />
      <path
        d="M40 13 Q50 20 50 32 Q50 44 40 51"
        stroke={color}
        strokeWidth="1.8"
        fill="none"
        strokeLinecap="round"
        opacity="0.55"
      />
    </svg>
  )
}

export function LogoLockup({ size = 64, color = '#1a1a1a', style }: { size?: number; color?: string; style?: CSSProperties }) {
  return (
    <div className="flex flex-col items-center" style={style}>
      <LogoMark size={size} color={color} />
      <div className="font-display tracking-[0.35em] mt-2" style={{ color, fontSize: size * 0.35, fontWeight: 500 }}>
        DIRI
      </div>
      <div className="font-sans tracking-tight italic text-ink-400 mt-0.5" style={{ fontSize: size * 0.18 }}>
        menata diri, bahagia hari ini
      </div>
    </div>
  )
}

export function Splash() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-cream-100">
      <div className="animate-pulse-soft">
        <LogoLockup size={72} />
      </div>
    </div>
  )
}
