import { Outlet, NavLink, useLocation } from 'react-router-dom'
import { LogoMark } from './Splash'

const tabs = [
  {
    to: '/app/home',
    label: 'Home',
    icon: (active: boolean) => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path
          d="M3 11.5L12 4l9 7.5V20a1 1 0 01-1 1h-5v-7H9v7H4a1 1 0 01-1-1v-8.5z"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinejoin="round"
          fill={active ? 'currentColor' : 'none'}
          fillOpacity={active ? 0.12 : 0}
        />
      </svg>
    )
  },
  {
    to: '/app/search',
    label: 'Cari',
    icon: () => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.6" />
        <path d="M16 16l4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
    )
  },
  {
    to: '/app/camera',
    label: 'Kamera',
    icon: (active: boolean) => (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="11" fill={active ? '#1a1a1a' : '#1a1a1a'} />
        <circle cx="12" cy="12" r="4.5" stroke="#f5f1ea" strokeWidth="1.6" fill="none" />
        <circle cx="12" cy="12" r="2" fill="#f5f1ea" />
      </svg>
    )
  },
  {
    to: '/app/chat',
    label: 'Stylist',
    icon: () => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path
          d="M4 5a2 2 0 012-2h12a2 2 0 012 2v9a2 2 0 01-2 2h-5l-4 4v-4H6a2 2 0 01-2-2V5z"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
      </svg>
    )
  },
  {
    to: '/app/profile',
    label: 'Profil',
    icon: () => (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="8" r="3.5" stroke="currentColor" strokeWidth="1.6" />
        <path d="M4 20c1.5-3.5 4.5-5 8-5s6.5 1.5 8 5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </svg>
    )
  }
]

export function AppShell() {
  const location = useLocation()
  const isCamera = location.pathname.includes('/camera')

  return (
    <div className="min-h-screen flex flex-col bg-cream-100">
      {/* Top bar — hide on camera for immersive */}
      {!isCamera && (
        <header className="sticky top-0 z-40 glass border-b border-ink-100/50">
          <div className="max-w-6xl mx-auto px-5 h-14 flex items-center justify-between pt-safe">
            <NavLink to="/app/home" className="flex items-center gap-2">
              <LogoMark size={28} />
              <span className="font-display tracking-[0.3em] text-sm font-medium">DIRI</span>
            </NavLink>
            <NavLink to="/app/wardrobe" className="text-xs uppercase tracking-widest text-ink-600 hover:text-ink-900">
              Lemari
            </NavLink>
          </div>
        </header>
      )}

      <main className={`flex-1 ${isCamera ? '' : 'pb-24'}`}>
        <Outlet />
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 glass border-t border-ink-100/50 pb-safe">
        <div className="max-w-md mx-auto px-2 py-2 grid grid-cols-5">
          {tabs.map(t => (
            <NavLink
              key={t.to}
              to={t.to}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-2xl transition-colors ${
                  isActive ? 'text-ink-900' : 'text-ink-400'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {t.icon(isActive)}
                  <span className="text-[10px] tracking-wide font-medium">{t.label}</span>
                </>
              )}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  )
}
