import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import type { User, UserProfile } from '@/types'
import { storage, uid } from '@/lib/storage'

interface StoredUser extends User {
  passwordHash: string
}

interface AuthContextValue {
  user: User | null
  profile: UserProfile
  loading: boolean
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>
  register: (name: string, email: string, password: string) => Promise<{ ok: boolean; error?: string }>
  logout: () => void
  updateProfile: (patch: Partial<UserProfile>) => void
}

const EMPTY_PROFILE: UserProfile = {
  gender: null,
  age: null,
  heightCm: null,
  weightKg: null,
  bodyType: null,
  skintone: null,
  undertone: null,
  headStyle: null,
  stylePreferences: [],
  lifestylePreferences: [],
  colorPreferences: [],
  budget: null,
  preferredBrands: [],
  occupationOrLifestyle: '',
  completed: false
}

const AuthContext = createContext<AuthContextValue | null>(null)

// Tiny hash for MVP — NOT cryptographically secure. Replace with backend auth later.
async function simpleHash(s: string): Promise<string> {
  const data = new TextEncoder().encode(s + 'diri-salt-v1')
  const buf = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('')
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile>(EMPTY_PROFILE)
  const [loading, setLoading] = useState(true)

  // Hydrate session on mount
  useEffect(() => {
    const sessionUserId = storage.get<string | null>('session', null)
    if (sessionUserId) {
      const users = storage.get<StoredUser[]>('users', [])
      const u = users.find(x => x.id === sessionUserId)
      if (u) {
        const { passwordHash, ...publicUser } = u
        void passwordHash
        setUser(publicUser)
        const p = storage.get<UserProfile>(`profile:${u.id}`, EMPTY_PROFILE)
        setProfile(p)
      }
    }
    setLoading(false)
  }, [])

  async function login(email: string, password: string) {
    const users = storage.get<StoredUser[]>('users', [])
    const u = users.find(x => x.email.toLowerCase() === email.toLowerCase())
    if (!u) return { ok: false, error: 'Email belum terdaftar.' }
    const hash = await simpleHash(password)
    if (hash !== u.passwordHash) return { ok: false, error: 'Password salah.' }
    storage.set('session', u.id)
    const { passwordHash, ...publicUser } = u
    void passwordHash
    setUser(publicUser)
    const p = storage.get<UserProfile>(`profile:${u.id}`, EMPTY_PROFILE)
    setProfile(p)
    return { ok: true }
  }

  async function register(name: string, email: string, password: string) {
    if (password.length < 6) return { ok: false, error: 'Password minimal 6 karakter.' }
    const users = storage.get<StoredUser[]>('users', [])
    if (users.some(x => x.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'Email sudah terdaftar. Silakan login.' }
    }
    const newUser: StoredUser = {
      id: uid('u_'),
      email,
      name,
      passwordHash: await simpleHash(password),
      createdAt: new Date().toISOString()
    }
    storage.set('users', [...users, newUser])
    storage.set('session', newUser.id)
    storage.set(`profile:${newUser.id}`, EMPTY_PROFILE)
    const { passwordHash, ...publicUser } = newUser
    void passwordHash
    setUser(publicUser)
    setProfile(EMPTY_PROFILE)
    return { ok: true }
  }

  function logout() {
    storage.remove('session')
    setUser(null)
    setProfile(EMPTY_PROFILE)
  }

  function updateProfile(patch: Partial<UserProfile>) {
    if (!user) return
    const merged = { ...profile, ...patch }
    setProfile(merged)
    storage.set(`profile:${user.id}`, merged)
  }

  return (
    <AuthContext.Provider value={{ user, profile, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}

export { EMPTY_PROFILE }
