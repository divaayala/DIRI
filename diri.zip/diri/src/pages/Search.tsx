import { useMemo, useState } from 'react'
import { PRODUCTS, formatRupiah, buildMarketplaceUrl } from '@/data/products'
import type { Product } from '@/types'

const CATEGORIES: Array<{ v: Product['category'] | 'all'; label: string }> = [
  { v: 'all', label: 'Semua' },
  { v: 'atasan', label: 'Atasan' },
  { v: 'outer', label: 'Outer' },
  { v: 'bawahan', label: 'Bawahan' },
  { v: 'sepatu', label: 'Sepatu' },
  { v: 'tas', label: 'Tas' },
  { v: 'topi', label: 'Topi' },
  { v: 'aksesoris', label: 'Aksesoris' }
]

export function Search() {
  const [q, setQ] = useState('')
  const [cat, setCat] = useState<Product['category'] | 'all'>('all')
  const [selected, setSelected] = useState<Product | null>(null)

  const results = useMemo(() => {
    const query = q.trim().toLowerCase()
    return PRODUCTS.filter(p => {
      if (cat !== 'all' && p.category !== cat) return false
      if (!query) return true
      return [
        p.name, p.brand, ...p.colors, ...p.tags, p.category
      ].some(s => s.toLowerCase().includes(query))
    })
  }, [q, cat])

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-6">
      <h1 className="font-display text-3xl font-light mb-4">Cari outfit</h1>

      <div className="sticky top-14 z-30 -mx-4 px-4 md:mx-0 md:px-0 py-3 bg-cream-100/95 backdrop-blur-sm">
        <div className="relative">
          <input
            type="search"
            className="input-field pl-11"
            placeholder="Cari: kemeja linen, sneakers, kerudung pashmina..."
            value={q}
            onChange={e => setQ(e.target.value)}
          />
          <svg className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-400" width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="1.6" />
            <path d="M16 16l4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </div>

        <div className="flex gap-2 mt-3 overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0 [&::-webkit-scrollbar]:hidden">
          {CATEGORIES.map(c => (
            <button
              key={c.v}
              onClick={() => setCat(c.v)}
              className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-medium border transition ${
                cat === c.v
                  ? 'bg-ink-900 text-cream-50 border-ink-900'
                  : 'bg-cream-50 text-ink-600 border-ink-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      <p className="text-xs text-ink-400 mt-3 mb-3">{results.length} item ditemukan</p>

      <div className="masonry">
        {results.map(p => (
          <button key={p.id} onClick={() => setSelected(p)} className="block w-full text-left bg-cream-50 rounded-2xl overflow-hidden border border-ink-100 group">
            <div className="relative">
              <img src={p.imageUrl} alt={p.name} loading="lazy" className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="p-2.5">
              <div className="text-xs font-medium truncate">{p.name}</div>
              <div className="text-[10px] text-ink-400 uppercase tracking-wider mt-0.5">{p.brand}</div>
              <div className="text-xs font-medium mt-1">{formatRupiah(p.price)}</div>
            </div>
          </button>
        ))}
      </div>

      {results.length === 0 && (
        <div className="text-center py-12 text-ink-400">
          <p>Tidak ada hasil untuk pencarian ini.</p>
        </div>
      )}

      {selected && <ProductDetail product={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

export function ProductDetail({ product, onClose }: { product: Product; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[60] bg-ink-900/70 backdrop-blur-sm flex items-end md:items-center justify-center p-0 md:p-6 animate-fade-in" onClick={onClose}>
      <div className="bg-cream-50 w-full md:max-w-md rounded-t-3xl md:rounded-3xl overflow-hidden animate-slide-up" onClick={e => e.stopPropagation()}>
        <div className="relative">
          <img src={product.imageUrl} alt={product.name} className="w-full aspect-square object-cover" />
          <button onClick={onClose} className="absolute top-3 right-3 w-10 h-10 rounded-full glass-dark text-cream-50 flex items-center justify-center">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6l-12 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg>
          </button>
        </div>
        <div className="p-5 pb-6">
          <p className="text-[11px] uppercase tracking-widest text-ink-400">{product.brand} · {product.category}</p>
          <h3 className="font-display text-xl mt-1">{product.name}</h3>
          <p className="text-2xl font-medium mt-2">{formatRupiah(product.price)}</p>
          <div className="flex flex-wrap gap-1.5 mt-3">
            {product.colors.map(c => (
              <span key={c} className="text-xs px-2.5 py-1 rounded-full bg-cream-100 border border-ink-100">{c}</span>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2">
            {product.tags.map(c => (
              <span key={c} className="text-[10px] px-2 py-0.5 rounded-full bg-ink-900 text-cream-50">{c}</span>
            ))}
          </div>
          <a href={buildMarketplaceUrl(product)} target="_blank" rel="noreferrer noopener" className="btn-primary w-full mt-5 inline-block text-center">
            Beli di {product.marketplace === 'tokopedia' ? 'Tokopedia' : product.marketplace === 'shopee' ? 'Shopee' : 'Zalora'}
          </a>
          <p className="text-[10px] text-ink-400 text-center mt-2 leading-relaxed">
            Akan membuka halaman pencarian marketplace di tab baru.
          </p>
        </div>
      </div>
    </div>
  )
}
