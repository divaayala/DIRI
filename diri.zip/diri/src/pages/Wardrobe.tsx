import { useEffect, useRef, useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import { storage, uid } from '@/lib/storage'
import type { WardrobeItem, WardrobeCategory } from '@/types'

const CATEGORIES: Array<{ v: WardrobeCategory; label: string }> = [
  { v: 'topi', label: 'Topi' },
  { v: 'baju', label: 'Baju' },
  { v: 'tas', label: 'Tas' },
  { v: 'celana', label: 'Celana' },
  { v: 'sepatu', label: 'Sepatu' },
  { v: 'aksesoris', label: 'Aksesoris' }
]

export function Wardrobe() {
  const { user } = useAuth()
  const [items, setItems] = useState<WardrobeItem[]>([])
  const [filter, setFilter] = useState<WardrobeCategory | 'all'>('all')
  const [draft, setDraft] = useState<{ imageDataUrl: string; label: string; category: WardrobeCategory } | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!user) return
    setItems(storage.get<WardrobeItem[]>(`wardrobe:${user.id}`, []))
  }, [user])

  function save(next: WardrobeItem[]) {
    if (!user) return
    setItems(next)
    storage.set(`wardrobe:${user.id}`, next)
  }

  function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 5_000_000) {
      alert('Ukuran foto maksimal 5MB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      setDraft({
        imageDataUrl: reader.result as string,
        label: file.name.replace(/\.[^.]+$/, ''),
        category: 'baju'
      })
    }
    reader.readAsDataURL(file)
    e.target.value = ''
  }

  function commitDraft() {
    if (!draft || !user) return
    const newItem: WardrobeItem = {
      id: uid('w_'),
      category: draft.category,
      label: draft.label.trim() || draft.category,
      imageDataUrl: draft.imageDataUrl,
      createdAt: new Date().toISOString()
    }
    save([newItem, ...items])
    setDraft(null)
  }

  function remove(id: string) {
    if (!confirm('Hapus item ini dari lemari?')) return
    save(items.filter(i => i.id !== id))
  }

  const filtered = filter === 'all' ? items : items.filter(i => i.category === filter)

  return (
    <div className="max-w-4xl mx-auto px-5 py-6">
      <div className="flex items-center justify-between mb-1">
        <h1 className="font-display text-3xl font-light">Lemari pribadi</h1>
        <button
          onClick={() => fileRef.current?.click()}
          className="bg-ink-900 text-cream-50 px-3.5 py-2 rounded-full text-xs font-medium flex items-center gap-1.5"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
          Upload
        </button>
      </div>
      <p className="text-sm text-ink-400 mb-4">
        Tambah foto baju yang kamu miliki. Nanti bisa dipakai untuk try-on di kamera dan dipertimbangkan stylist.
      </p>

      <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={onFile} className="hidden" />

      {/* Filter */}
      <div className="flex gap-2 mb-4 overflow-x-auto -mx-5 px-5 [&::-webkit-scrollbar]:hidden">
        <FilterChip active={filter === 'all'} onClick={() => setFilter('all')}>Semua ({items.length})</FilterChip>
        {CATEGORIES.map(c => {
          const count = items.filter(i => i.category === c.v).length
          return (
            <FilterChip key={c.v} active={filter === c.v} onClick={() => setFilter(c.v)}>
              {c.label} ({count})
            </FilterChip>
          )
        })}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-12 text-ink-400">
          <p className="text-sm">
            {items.length === 0
              ? 'Lemari kamu masih kosong. Upload foto baju pertamamu.'
              : 'Belum ada item di kategori ini.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {filtered.map(it => (
            <div key={it.id} className="bg-cream-50 rounded-2xl overflow-hidden border border-ink-100">
              <div className="aspect-square relative">
                <img src={it.imageDataUrl} alt={it.label} className="w-full h-full object-cover" />
                <button
                  onClick={() => remove(it.id)}
                  className="absolute top-2 right-2 w-8 h-8 rounded-full glass-dark text-cream-50 flex items-center justify-center"
                  aria-label="Hapus"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6l-12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
                </button>
              </div>
              <div className="p-2.5">
                <div className="text-xs font-medium truncate">{it.label}</div>
                <div className="text-[10px] text-ink-400 uppercase tracking-wider">{it.category}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {draft && (
        <div className="fixed inset-0 z-[70] bg-ink-900/80 backdrop-blur-sm flex items-end md:items-center justify-center p-0 md:p-6" onClick={() => setDraft(null)}>
          <div className="bg-cream-50 w-full md:max-w-md rounded-t-3xl md:rounded-3xl overflow-hidden animate-slide-up" onClick={e => e.stopPropagation()}>
            <img src={draft.imageDataUrl} alt="" className="w-full aspect-square object-cover" />
            <div className="p-5 space-y-3">
              <div>
                <label className="text-[11px] uppercase tracking-widest text-ink-400 mb-1.5 block">Nama item</label>
                <input
                  type="text"
                  className="input-field"
                  value={draft.label}
                  onChange={e => setDraft({ ...draft, label: e.target.value })}
                  placeholder="Kaos hitam basic"
                />
              </div>
              <div>
                <label className="text-[11px] uppercase tracking-widest text-ink-400 mb-1.5 block">Kategori</label>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORIES.map(c => (
                    <button
                      key={c.v}
                      type="button"
                      onClick={() => setDraft({ ...draft, category: c.v })}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
                        draft.category === c.v ? 'bg-ink-900 text-cream-50 border-ink-900' : 'bg-cream-50 border-ink-200 text-ink-600'
                      }`}
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-2 pt-2 pb-safe">
                <button onClick={() => setDraft(null)} className="btn-ghost flex-1 border border-ink-200">Batal</button>
                <button onClick={commitDraft} className="btn-primary flex-1">Simpan</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <p className="text-[11px] text-ink-400 mt-8 leading-relaxed text-center">
        Foto disimpan lokal di browser kamu (base64).<br />
        Untuk hasil terbaik, foto baju dengan latar polos.
      </p>
    </div>
  )
}

function FilterChip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition ${
        active ? 'bg-ink-900 text-cream-50 border-ink-900' : 'bg-cream-50 text-ink-600 border-ink-200'
      }`}
    >
      {children}
    </button>
  )
}
