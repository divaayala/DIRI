import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { PRODUCTS, formatRupiah, buildMarketplaceUrl } from '@/data/products'
import type { Product } from '@/types'

// Curated "outfit inspiration" — combinations from catalog (hard-coded but rotated)
const INSPIRATION_FEED: Array<{
  title: string
  vibe: string
  items: string[] // product ids
  cover: string
  tone: 'warm' | 'cool' | 'neutral'
  forHijab: boolean
}> = [
  { title: 'Coffee shop weekend', vibe: 'minimalis · krem · effortless', items: ['p001', 'p018', 'p024', 'p031'], cover: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=800&q=80&auto=format&fit=crop', tone: 'warm', forHijab: false },
  { title: 'Senin pagi rapat', vibe: 'smart-casual · navy · rapi', items: ['p002', 'p022', 'p026', 'p035'], cover: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&q=80&auto=format&fit=crop', tone: 'cool', forHijab: false },
  { title: 'Pengajian sore', vibe: 'modest · mocca · soft', items: ['p047', 'p040', 'p028', 'p034'], cover: 'https://images.unsplash.com/photo-1622260614153-03223fb72052?w=800&q=80&auto=format&fit=crop', tone: 'warm', forHijab: true },
  { title: 'Streetwear Friday', vibe: 'edgy · oversized · monokrom', items: ['p005', 'p019', 'p025', 'p036'], cover: 'https://images.unsplash.com/photo-1490114538077-0a7f8cb49891?w=800&q=80&auto=format&fit=crop', tone: 'cool', forHijab: false },
  { title: 'Kondangan outdoor', vibe: 'feminin · pastel · klasik', items: ['p004', 'p020', 'p027', 'p044'], cover: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&q=80&auto=format&fit=crop', tone: 'neutral', forHijab: false },
  { title: 'Hijab kantor', vibe: 'modest · sage · professional', items: ['p006', 'p021', 'p028', 'p039'], cover: 'https://images.unsplash.com/photo-1611042553484-d61f84d22784?w=800&q=80&auto=format&fit=crop', tone: 'neutral', forHijab: true },
  { title: 'Date night', vibe: 'klasik · merah marun · elegan', items: ['p004', 'p022', 'p027', 'p041'], cover: 'https://images.unsplash.com/photo-1496217590455-aa63a8350eea?w=800&q=80&auto=format&fit=crop', tone: 'warm', forHijab: false },
  { title: 'Tema 17 Agustus', vibe: 'putih merah · semi-formal', items: ['p002', 'p017', 'p024', 'p042'], cover: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&q=80&auto=format&fit=crop', tone: 'cool', forHijab: false },
  { title: 'Weekend mall', vibe: 'kasual · denim · simple', items: ['p007', 'p017', 'p024', 'p032'], cover: 'https://images.unsplash.com/photo-1485518882345-15568b007407?w=800&q=80&auto=format&fit=crop', tone: 'cool', forHijab: false },
  { title: 'Travel city', vibe: 'fungsional · krem · ringan', items: ['p001', 'p016', 'p030', 'p033'], cover: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800&q=80&auto=format&fit=crop', tone: 'warm', forHijab: false },
  { title: 'Modest casual', vibe: 'modest · tunik · nyaman', items: ['p006', 'p016', 'p030', 'p040'], cover: 'https://images.unsplash.com/photo-1601762603339-fd61e28b698a?w=800&q=80&auto=format&fit=crop', tone: 'warm', forHijab: true },
  { title: 'Sneakers head', vibe: 'streetwear · denim · sneakers', items: ['p010', 'p017', 'p050', 'p037'], cover: 'https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&q=80&auto=format&fit=crop', tone: 'neutral', forHijab: false }
]

export function Home() {
  const { user, profile } = useAuth()

  const feed = useMemo(() => {
    const isHijab = profile.headStyle === 'kerudung'
    // prioritize relevant + tone
    return [...INSPIRATION_FEED].sort((a, b) => {
      const aRelevant = (isHijab ? a.forHijab : !a.forHijab) ? 1 : 0
      const bRelevant = (isHijab ? b.forHijab : !b.forHijab) ? 1 : 0
      if (aRelevant !== bRelevant) return bRelevant - aRelevant
      const aTone = profile.undertone && a.tone === profile.undertone ? 1 : 0
      const bTone = profile.undertone && b.tone === profile.undertone ? 1 : 0
      return bTone - aTone
    })
  }, [profile])

  return (
    <div className="max-w-6xl mx-auto px-4 md:px-6 py-6">
      <section className="mb-6">
        <p className="text-xs uppercase tracking-widest text-ink-400">
          {greet()}, {user?.name?.split(' ')[0]}
        </p>
        <h1 className="font-display text-3xl md:text-4xl font-light mt-1 text-balance">
          Inspirasi outfit untuk hari ini
        </h1>
      </section>

      {/* Quick actions */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0 [&::-webkit-scrollbar]:hidden">
        <Link to="/app/chat" className="shrink-0 bg-ink-900 text-cream-50 px-4 py-2.5 rounded-full text-sm font-medium hover:bg-ink-800">
          Tanya stylist
        </Link>
        <Link to="/app/camera" className="shrink-0 bg-cream-50 border border-ink-200 px-4 py-2.5 rounded-full text-sm font-medium">
          Try-on kamera
        </Link>
        <Link to="/app/search" className="shrink-0 bg-cream-50 border border-ink-200 px-4 py-2.5 rounded-full text-sm font-medium">
          Cari outfit
        </Link>
        <Link to="/app/wardrobe" className="shrink-0 bg-cream-50 border border-ink-200 px-4 py-2.5 rounded-full text-sm font-medium">
          Lemari pribadi
        </Link>
      </div>

      {/* Masonry feed */}
      <div className="masonry">
        {feed.map((item, idx) => (
          <InspirationCard key={idx} item={item} />
        ))}
      </div>

      <div className="text-center text-xs text-ink-400 mt-10 tracking-widest uppercase">
        — Lebih banyak akan datang —
      </div>
    </div>
  )
}

function greet() {
  const h = new Date().getHours()
  if (h < 11) return 'Selamat pagi'
  if (h < 15) return 'Selamat siang'
  if (h < 18) return 'Selamat sore'
  return 'Selamat malam'
}

function InspirationCard({ item }: { item: typeof INSPIRATION_FEED[number] }) {
  const products = item.items.map(id => PRODUCTS.find(p => p.id === id)).filter(Boolean) as Product[]
  const total = products.reduce((s, p) => s + p.price, 0)
  // varied heights for masonry
  const heights = ['aspect-[3/4]', 'aspect-[4/5]', 'aspect-[2/3]']
  const h = heights[Math.abs(item.title.length) % heights.length]

  return (
    <details className="group bg-cream-50 rounded-3xl overflow-hidden border border-ink-100">
      <summary className="list-none cursor-pointer">
        <div className={`relative ${h} overflow-hidden`}>
          <img src={item.cover} alt={item.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-900/70 via-transparent to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-3 text-cream-50">
            <div className="font-display text-base leading-tight">{item.title}</div>
            <div className="text-[11px] opacity-80 mt-0.5">{item.vibe}</div>
          </div>
        </div>
        <div className="px-3 py-2.5 flex items-center justify-between text-xs">
          <span className="text-ink-400">{products.length} item</span>
          <span className="font-medium">{formatRupiah(total)}</span>
        </div>
      </summary>
      <div className="border-t border-ink-100 p-3 space-y-2">
        {products.map(p => (
          <a key={p.id} href={buildMarketplaceUrl(p)} target="_blank" rel="noreferrer noopener"
             className="flex items-center gap-3 group/item hover:bg-cream-100 rounded-2xl p-1.5 -m-1.5 transition-colors">
            <img src={p.imageUrl} alt={p.name} loading="lazy" className="w-12 h-12 rounded-xl object-cover bg-ink-100" />
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium truncate">{p.name}</div>
              <div className="text-[10px] text-ink-400 uppercase tracking-wider">{p.brand} · {p.category}</div>
            </div>
            <div className="text-xs font-medium">{formatRupiah(p.price)}</div>
          </a>
        ))}
      </div>
    </details>
  )
}
