import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { LogoMark } from '@/components/Splash'
import type { UserProfile, BodyType, Skintone, Undertone, HeadStyle, Budget, Gender } from '@/types'

const STYLE_OPTIONS = ['minimalis', 'streetwear', 'klasik', 'feminin', 'edgy', 'sporty', 'vintage', 'bohemian', 'preppy', 'modest', 'smart-casual', 'glam']
const LIFESTYLE_OPTIONS = ['mahasiswa', 'kantoran', 'kreatif', 'wirausaha', 'aktif/olahraga', 'ibu rumah tangga', 'sering bepergian', 'work from home']
const COLOR_OPTIONS = ['hitam', 'putih', 'krem', 'cokelat', 'navy', 'abu', 'olive', 'mocca', 'dusty pink', 'merah', 'mustard', 'sage', 'lavender', 'pastel']
const BRAND_OPTIONS = ['Uniqlo', 'Zara', 'H&M', 'Cotton Ink', 'Erigo', 'Buttonscarves', 'Pull&Bear', 'Massimo Dutti', 'Adidas', 'Nike', 'New Balance', 'Local IDN']

interface StepProps {
  data: UserProfile
  setData: (patch: Partial<UserProfile>) => void
  next: () => void
  prev: () => void
  isFirst: boolean
  isLast: boolean
}

export function Onboarding() {
  const { updateProfile, profile } = useAuth()
  const nav = useNavigate()
  const [step, setStep] = useState(0)
  const [data, setData] = useState<UserProfile>(profile)

  const setPatch = (patch: Partial<UserProfile>) => setData(d => ({ ...d, ...patch }))

  const steps = [
    StepGender,
    StepBody,
    StepHead,
    StepSkin,
    StepStyle,
    StepLifestyle,
    StepColor,
    StepBudget,
    StepFinal
  ]
  const Step = steps[step]
  const progress = ((step + 1) / steps.length) * 100

  function next() {
    if (step < steps.length - 1) setStep(step + 1)
    else finish()
  }
  function prev() {
    if (step > 0) setStep(step - 1)
  }
  function finish() {
    updateProfile({ ...data, completed: true })
    nav('/app/home', { replace: true })
  }

  return (
    <div className="min-h-screen bg-cream-100 flex flex-col">
      <header className="px-6 pt-8 pb-4 flex items-center justify-between">
        <LogoMark size={28} />
        <button onClick={() => setStep(steps.length - 1)} className="text-xs uppercase tracking-widest text-ink-400 hover:text-ink-600">
          Lewati ke akhir
        </button>
      </header>

      <div className="px-6">
        <div className="h-0.5 bg-ink-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-ink-900 transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between mt-2">
          <span className="text-[11px] tracking-widest uppercase text-ink-400">
            Langkah {step + 1} dari {steps.length}
          </span>
        </div>
      </div>

      <main className="flex-1 px-6 py-8 max-w-md mx-auto w-full animate-fade-in" key={step}>
        <Step
          data={data}
          setData={setPatch}
          next={next}
          prev={prev}
          isFirst={step === 0}
          isLast={step === steps.length - 1}
        />
      </main>
    </div>
  )
}

function StepShell({
  title, subtitle, children, next, prev, isFirst, isLast, canNext = true
}: {
  title: string; subtitle?: string; children: React.ReactNode
  next: () => void; prev: () => void; isFirst: boolean; isLast: boolean; canNext?: boolean
}) {
  return (
    <div className="flex flex-col h-full">
      <h2 className="font-display text-3xl font-light mb-2 text-balance">{title}</h2>
      {subtitle && <p className="text-ink-400 text-sm mb-6 text-balance">{subtitle}</p>}
      <div className="flex-1">{children}</div>
      <div className="flex gap-3 mt-8">
        {!isFirst && (
          <button onClick={prev} className="btn-ghost flex-1 border border-ink-200">Kembali</button>
        )}
        <button onClick={next} disabled={!canNext} className="btn-primary flex-1 disabled:opacity-40 disabled:cursor-not-allowed">
          {isLast ? 'Mulai pakai DIRI' : 'Lanjut'}
        </button>
      </div>
    </div>
  )
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-4 py-2.5 rounded-full text-sm font-medium border transition-all ${
        active
          ? 'bg-ink-900 text-cream-50 border-ink-900'
          : 'bg-cream-50 text-ink-600 border-ink-200 hover:border-ink-400'
      }`}
    >
      {children}
    </button>
  )
}

function StepGender({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  const opts: Array<{ v: Gender; label: string }> = [
    { v: 'wanita', label: 'Wanita' },
    { v: 'pria', label: 'Pria' },
    { v: 'lainnya', label: 'Tidak ingin menjawab' }
  ]
  return (
    <StepShell
      title="Halo, kenalan dulu yuk"
      subtitle="Beberapa info dasar biar rekomendasi outfit kami lebih relevan untukmu."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={!!data.gender && !!data.age && !!data.heightCm && !!data.weightKg}
    >
      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Gender</label>
      <div className="flex flex-wrap gap-2 mb-6">
        {opts.map(o => (
          <Chip key={o.v} active={data.gender === o.v} onClick={() => setData({ gender: o.v })}>{o.label}</Chip>
        ))}
      </div>

      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Usia</label>
      <input
        type="number" min={10} max={100}
        className="input-field mb-6" placeholder="contoh: 22"
        value={data.age ?? ''} onChange={e => setData({ age: e.target.value ? Number(e.target.value) : null })}
      />

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Tinggi (cm)</label>
          <input
            type="number" min={120} max={220}
            className="input-field" placeholder="160"
            value={data.heightCm ?? ''} onChange={e => setData({ heightCm: e.target.value ? Number(e.target.value) : null })}
          />
        </div>
        <div>
          <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Berat (kg)</label>
          <input
            type="number" min={30} max={200}
            className="input-field" placeholder="55"
            value={data.weightKg ?? ''} onChange={e => setData({ weightKg: e.target.value ? Number(e.target.value) : null })}
          />
        </div>
      </div>
    </StepShell>
  )
}

function StepBody({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  const opts: Array<{ v: BodyType; label: string; desc: string }> = [
    { v: 'rectangle', label: 'Rectangle', desc: 'Bahu, pinggang, pinggul sejajar.' },
    { v: 'hourglass', label: 'Hourglass', desc: 'Bahu = pinggul, pinggang ramping.' },
    { v: 'pear', label: 'Pear', desc: 'Pinggul lebih lebar dari bahu.' },
    { v: 'apple', label: 'Apple', desc: 'Bagian tengah lebih berisi.' },
    { v: 'inverted-triangle', label: 'Inverted Triangle', desc: 'Bahu lebih lebar dari pinggul.' },
    { v: 'athletic', label: 'Athletic', desc: 'Berotot, garis tegas.' },
    { v: 'slim', label: 'Slim', desc: 'Ramping, garis lurus.' },
    { v: 'plus', label: 'Plus / Curvy', desc: 'Berisi merata.' }
  ]
  return (
    <StepShell
      title="Bagaimana bentuk tubuhmu?"
      subtitle="Tidak yakin? Pilih yang paling mirip — bisa diubah nanti di profil."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={!!data.bodyType}
    >
      <div className="grid grid-cols-1 gap-2">
        {opts.map(o => (
          <button
            key={o.v}
            type="button"
            onClick={() => setData({ bodyType: o.v })}
            className={`text-left p-4 rounded-2xl border transition-all ${
              data.bodyType === o.v
                ? 'bg-ink-900 text-cream-50 border-ink-900'
                : 'bg-cream-50 text-ink-900 border-ink-200 hover:border-ink-400'
            }`}
          >
            <div className="font-medium">{o.label}</div>
            <div className={`text-xs mt-0.5 ${data.bodyType === o.v ? 'text-cream-200' : 'text-ink-400'}`}>{o.desc}</div>
          </button>
        ))}
      </div>
    </StepShell>
  )
}

function StepHead({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  const opts: Array<{ v: HeadStyle; label: string }> = [
    { v: 'rambut-pendek', label: 'Rambut pendek' },
    { v: 'rambut-panjang', label: 'Rambut panjang' },
    { v: 'kerudung', label: 'Berkerudung / Hijab' },
    { v: 'topi', label: 'Sering pakai topi' }
  ]
  return (
    <StepShell
      title="Bagian kepala & rambut"
      subtitle="Penting untuk menyesuaikan rekomendasi modest/non-modest dan padu padan aksesoris."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={!!data.headStyle}
    >
      <div className="flex flex-wrap gap-2">
        {opts.map(o => (
          <Chip key={o.v} active={data.headStyle === o.v} onClick={() => setData({ headStyle: o.v })}>{o.label}</Chip>
        ))}
      </div>
    </StepShell>
  )
}

function StepSkin({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  const skinOpts: Array<{ v: Skintone; label: string; hex: string }> = [
    { v: 'sangat-terang', label: 'Sangat terang', hex: '#f4e4d0' },
    { v: 'terang', label: 'Terang', hex: '#e8c7a8' },
    { v: 'sedang', label: 'Sedang', hex: '#cda07a' },
    { v: 'sawo-matang', label: 'Sawo matang', hex: '#a47148' },
    { v: 'gelap', label: 'Gelap', hex: '#6f4a2e' }
  ]
  const underOpts: Array<{ v: Undertone; label: string; hint: string }> = [
    { v: 'warm', label: 'Warm', hint: 'Vena kekuningan, cocok dengan gold' },
    { v: 'cool', label: 'Cool', hint: 'Vena kebiruan, cocok dengan silver' },
    { v: 'neutral', label: 'Neutral', hint: 'Campuran, cocok dengan keduanya' }
  ]
  return (
    <StepShell
      title="Skintone & undertone"
      subtitle="Membantu menentukan palet warna yang paling nyala di kulitmu."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={!!data.skintone && !!data.undertone}
    >
      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Skintone</label>
      <div className="grid grid-cols-5 gap-2 mb-6">
        {skinOpts.map(o => (
          <button
            key={o.v}
            type="button"
            onClick={() => setData({ skintone: o.v })}
            className={`flex flex-col items-center gap-1 p-2 rounded-2xl border transition-all ${
              data.skintone === o.v ? 'border-ink-900 bg-cream-50' : 'border-transparent hover:border-ink-200'
            }`}
          >
            <span className="w-10 h-10 rounded-full ring-1 ring-ink-100" style={{ background: o.hex }} />
            <span className="text-[10px] text-center text-ink-600 leading-tight">{o.label}</span>
          </button>
        ))}
      </div>

      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Undertone</label>
      <div className="space-y-2">
        {underOpts.map(o => (
          <button
            key={o.v}
            type="button"
            onClick={() => setData({ undertone: o.v })}
            className={`w-full text-left p-3 rounded-2xl border transition-all ${
              data.undertone === o.v
                ? 'bg-ink-900 text-cream-50 border-ink-900'
                : 'bg-cream-50 border-ink-200 hover:border-ink-400'
            }`}
          >
            <div className="font-medium">{o.label}</div>
            <div className={`text-xs mt-0.5 ${data.undertone === o.v ? 'text-cream-200' : 'text-ink-400'}`}>{o.hint}</div>
          </button>
        ))}
      </div>
    </StepShell>
  )
}

function StepStyle({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  function toggle(s: string) {
    const cur = data.stylePreferences
    setData({ stylePreferences: cur.includes(s) ? cur.filter(x => x !== s) : [...cur, s] })
  }
  return (
    <StepShell
      title="Gaya yang kamu suka"
      subtitle="Pilih 2-5 yang paling kamu banget."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={data.stylePreferences.length >= 1}
    >
      <div className="flex flex-wrap gap-2">
        {STYLE_OPTIONS.map(s => (
          <Chip key={s} active={data.stylePreferences.includes(s)} onClick={() => toggle(s)}>{s}</Chip>
        ))}
      </div>
    </StepShell>
  )
}

function StepLifestyle({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  function toggle(s: string) {
    const cur = data.lifestylePreferences
    setData({ lifestylePreferences: cur.includes(s) ? cur.filter(x => x !== s) : [...cur, s] })
  }
  return (
    <StepShell
      title="Aktivitas sehari-hari"
      subtitle="Outfit yang baik menyesuaikan ritme hidupmu."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={data.lifestylePreferences.length >= 1}
    >
      <div className="flex flex-wrap gap-2 mb-6">
        {LIFESTYLE_OPTIONS.map(s => (
          <Chip key={s} active={data.lifestylePreferences.includes(s)} onClick={() => toggle(s)}>{s}</Chip>
        ))}
      </div>
      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">
        Profesi / lifestyle (opsional)
      </label>
      <input
        type="text"
        className="input-field"
        placeholder="contoh: marketing di startup, suka café hopping"
        value={data.occupationOrLifestyle}
        onChange={e => setData({ occupationOrLifestyle: e.target.value })}
      />
    </StepShell>
  )
}

function StepColor({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  function toggle(s: string) {
    const cur = data.colorPreferences
    setData({ colorPreferences: cur.includes(s) ? cur.filter(x => x !== s) : [...cur, s] })
  }
  return (
    <StepShell
      title="Palet warna favorit"
      subtitle="Warna yang sering kamu pakai dan kamu nyaman dengannya."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={data.colorPreferences.length >= 1}
    >
      <div className="flex flex-wrap gap-2">
        {COLOR_OPTIONS.map(s => (
          <Chip key={s} active={data.colorPreferences.includes(s)} onClick={() => toggle(s)}>{s}</Chip>
        ))}
      </div>
    </StepShell>
  )
}

function StepBudget({ data, setData, next, prev, isFirst, isLast }: StepProps) {
  const opts: Array<{ v: Budget; label: string; range: string }> = [
    { v: 'hemat', label: 'Hemat', range: '< Rp 300rb / item' },
    { v: 'menengah', label: 'Menengah', range: 'Rp 300rb – 1jt / item' },
    { v: 'premium', label: 'Premium', range: 'Rp 1jt – 3jt / item' },
    { v: 'mewah', label: 'Mewah', range: '> Rp 3jt / item' }
  ]
  function toggleBrand(s: string) {
    const cur = data.preferredBrands
    setData({ preferredBrands: cur.includes(s) ? cur.filter(x => x !== s) : [...cur, s] })
  }
  return (
    <StepShell
      title="Budget & brand"
      subtitle="Biar rekomendasi sesuai kantong dan selera."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
      canNext={!!data.budget}
    >
      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Range budget per item</label>
      <div className="grid grid-cols-2 gap-2 mb-6">
        {opts.map(o => (
          <button
            key={o.v}
            type="button"
            onClick={() => setData({ budget: o.v })}
            className={`text-left p-3 rounded-2xl border transition-all ${
              data.budget === o.v
                ? 'bg-ink-900 text-cream-50 border-ink-900'
                : 'bg-cream-50 border-ink-200 hover:border-ink-400'
            }`}
          >
            <div className="font-medium">{o.label}</div>
            <div className={`text-[11px] mt-0.5 ${data.budget === o.v ? 'text-cream-200' : 'text-ink-400'}`}>{o.range}</div>
          </button>
        ))}
      </div>

      <label className="text-xs uppercase tracking-widest text-ink-400 mb-2 block">Brand favorit (opsional)</label>
      <div className="flex flex-wrap gap-2">
        {BRAND_OPTIONS.map(s => (
          <Chip key={s} active={data.preferredBrands.includes(s)} onClick={() => toggleBrand(s)}>{s}</Chip>
        ))}
      </div>
    </StepShell>
  )
}

function StepFinal({ next, prev, isFirst, isLast }: StepProps) {
  return (
    <StepShell
      title="Profilmu siap"
      subtitle="DIRI akan memakai info ini untuk menyusun setiap rekomendasi. Kamu bisa update kapan saja di tab Profil."
      next={next} prev={prev} isFirst={isFirst} isLast={isLast}
    >
      <div className="card p-6 text-center">
        <LogoMark size={48} />
        <p className="font-display italic text-ink-600 mt-4">menata diri, bahagia hari ini</p>
        <p className="text-sm text-ink-400 mt-3 leading-relaxed">
          Tap "Mulai pakai DIRI" untuk masuk ke beranda inspirasi.
        </p>
      </div>
    </StepShell>
  )
}
