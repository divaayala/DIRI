import { useEffect, useRef, useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import type { WardrobeItem, BodyType } from '@/types'
import { storage } from '@/lib/storage'
import { PRODUCTS } from '@/data/products'

type Mode = 'pose' | 'tryon'

export function Camera() {
  const { user, profile } = useAuth()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [facing, setFacing] = useState<'user' | 'environment'>('user')
  const [mode, setMode] = useState<Mode>('pose')
  const [overlay, setOverlay] = useState<string | null>(null) // image data url
  const [error, setError] = useState<string | null>(null)
  const [tryOnPickerOpen, setTryOnPickerOpen] = useState(false)
  const [captureUrl, setCaptureUrl] = useState<string | null>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    startCamera()
    return () => {
      stream?.getTracks().forEach(t => t.stop())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facing])

  async function startCamera() {
    setError(null)
    try {
      stream?.getTracks().forEach(t => t.stop())
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: facing, width: { ideal: 1080 }, height: { ideal: 1920 } },
        audio: false
      })
      setStream(s)
      if (videoRef.current) {
        videoRef.current.srcObject = s
      }
    } catch (e: any) {
      console.error(e)
      setError(
        e?.name === 'NotAllowedError'
          ? 'Izin kamera ditolak. Berikan izin di pengaturan browser lalu coba lagi.'
          : 'Tidak bisa mengakses kamera. Pastikan kamu pakai HTTPS atau localhost.'
      )
    }
  }

  function capture() {
    if (!videoRef.current || !canvasRef.current) return
    const v = videoRef.current
    const c = canvasRef.current
    c.width = v.videoWidth
    c.height = v.videoHeight
    const ctx = c.getContext('2d')
    if (!ctx) return
    if (facing === 'user') {
      // mirror selfie
      ctx.translate(c.width, 0)
      ctx.scale(-1, 1)
    }
    ctx.drawImage(v, 0, 0, c.width, c.height)
    // overlay on top
    if (overlay) {
      const img = new Image()
      img.crossOrigin = 'anonymous'
      img.onload = () => {
        // draw overlay in body area
        ctx.setTransform(1, 0, 0, 1, 0, 0)
        const w = c.width * 0.55
        const h = w * (img.height / img.width)
        const x = (c.width - w) / 2
        const y = c.height * 0.28
        ctx.drawImage(img, x, y, w, h)
        finalize()
      }
      img.onerror = finalize
      img.src = overlay
    } else {
      finalize()
    }

    function finalize() {
      setCaptureUrl(c.toDataURL('image/png'))
    }
  }

  function downloadCapture() {
    if (!captureUrl) return
    const a = document.createElement('a')
    a.href = captureUrl
    a.download = `diri-${Date.now()}.png`
    a.click()
  }

  async function shareCapture() {
    if (!captureUrl) return
    try {
      const blob = await (await fetch(captureUrl)).blob()
      const file = new File([blob], 'diri-outfit.png', { type: 'image/png' })
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title: 'Outfit-ku via DIRI', text: 'Nih outfit aku hari ini — pantes nggak?' })
      } else {
        downloadCapture()
      }
    } catch (e) {
      // user cancelled or share unsupported
    }
  }

  return (
    <div className="fixed inset-0 bg-ink-900 text-cream-50 flex flex-col">
      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 z-30 pt-safe glass-dark border-b border-cream-50/10">
        <div className="px-4 h-12 flex items-center justify-between">
          <div className="flex gap-1.5">
            <button
              onClick={() => { setMode('pose'); setOverlay(null) }}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition ${
                mode === 'pose' ? 'bg-cream-50 text-ink-900' : 'text-cream-50/70'
              }`}
            >
              Pose Frame
            </button>
            <button
              onClick={() => { setMode('tryon'); setTryOnPickerOpen(true) }}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition ${
                mode === 'tryon' ? 'bg-cream-50 text-ink-900' : 'text-cream-50/70'
              }`}
            >
              Try-On
            </button>
          </div>
          <button onClick={() => setFacing(f => f === 'user' ? 'environment' : 'user')} className="w-9 h-9 rounded-full glass-dark border border-cream-50/20 flex items-center justify-center">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M21 12a9 9 0 11-3.5-7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
              <path d="M21 4v5h-5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>

      {/* Video */}
      <div className="flex-1 relative overflow-hidden">
        {error ? (
          <div className="h-full flex items-center justify-center px-6 text-center">
            <div>
              <p className="text-sm mb-4">{error}</p>
              <button onClick={startCamera} className="bg-cream-50 text-ink-900 px-4 py-2 rounded-full text-sm font-medium">Coba lagi</button>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={`w-full h-full object-cover ${facing === 'user' ? 'scale-x-[-1]' : ''}`}
            />

            {/* Pose frame overlay — based on body type */}
            {mode === 'pose' && (
              <PoseFrameOverlay bodyType={profile.bodyType} headStyle={profile.headStyle} />
            )}

            {/* Try-on overlay */}
            {mode === 'tryon' && overlay && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <img src={overlay} alt="" className="max-w-[55%] max-h-[45%] object-contain" style={{ marginTop: '5%' }} />
              </div>
            )}

            {/* Hint */}
            <div className="absolute top-16 left-1/2 -translate-x-1/2 glass-dark text-xs px-3 py-1.5 rounded-full border border-cream-50/15 whitespace-nowrap">
              {mode === 'pose'
                ? 'Posisikan tubuhmu di dalam garis'
                : overlay ? 'Tap shutter untuk capture' : 'Pilih outfit dulu'}
            </div>
          </>
        )}
      </div>

      {/* Bottom controls */}
      <div className="absolute bottom-0 left-0 right-0 z-30 pb-safe glass-dark border-t border-cream-50/10">
        <div className="px-6 py-5 flex items-center justify-between">
          <button
            onClick={() => setTryOnPickerOpen(true)}
            className="w-12 h-12 rounded-2xl bg-cream-50/10 border border-cream-50/20 flex items-center justify-center"
            aria-label="Pilih outfit"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="6" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.6"/>
              <path d="M8 6V4a4 4 0 018 0v2" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
            </svg>
          </button>

          <button
            onClick={capture}
            disabled={!!error}
            className="w-18 h-18 rounded-full bg-cream-50 border-4 border-cream-50/40 flex items-center justify-center active:scale-95 transition disabled:opacity-40"
            style={{ width: 72, height: 72 }}
            aria-label="Capture"
          >
            <span className="block w-14 h-14 rounded-full bg-cream-50 border border-ink-900/10" />
          </button>

          <div className="w-12 h-12" />
        </div>
      </div>

      <canvas ref={canvasRef} className="hidden" />

      {captureUrl && (
        <CapturePreview
          url={captureUrl}
          onClose={() => setCaptureUrl(null)}
          onDownload={downloadCapture}
          onShare={shareCapture}
        />
      )}

      {tryOnPickerOpen && (
        <TryOnPicker
          onClose={() => setTryOnPickerOpen(false)}
          onPick={url => { setOverlay(url); setMode('tryon'); setTryOnPickerOpen(false) }}
          onClear={() => { setOverlay(null); setTryOnPickerOpen(false) }}
        />
      )}
    </div>
  )
}

function PoseFrameOverlay({ bodyType, headStyle }: { bodyType: BodyType | null; headStyle: any }) {
  // Different body silhouette per body type — drawn as SVG guide lines
  const isHijab = headStyle === 'kerudung'
  return (
    <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
      <svg viewBox="0 0 200 360" className="h-[88%] w-auto opacity-60" preserveAspectRatio="xMidYMid meet">
        <defs>
          <linearGradient id="poseStroke" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#fbf8f3" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#fbf8f3" stopOpacity="0.4" />
          </linearGradient>
        </defs>

        {/* Face/head circle or hijab oval */}
        {isHijab ? (
          <>
            <ellipse cx="100" cy="46" rx="38" ry="44" stroke="url(#poseStroke)" strokeWidth="1.5" fill="none" strokeDasharray="3 4" />
            <ellipse cx="100" cy="50" rx="24" ry="28" stroke="url(#poseStroke)" strokeWidth="1" fill="none" strokeDasharray="2 3" opacity="0.7" />
          </>
        ) : (
          <circle cx="100" cy="48" r="30" stroke="url(#poseStroke)" strokeWidth="1.5" fill="none" strokeDasharray="3 4" />
        )}

        {/* Body silhouette */}
        <BodyGuide bodyType={bodyType ?? 'rectangle'} />

        {/* Center line */}
        <line x1="100" y1="80" x2="100" y2="340" stroke="#fbf8f3" strokeOpacity="0.3" strokeWidth="0.7" strokeDasharray="2 6" />
        {/* Corner brackets */}
        <Bracket x={6} y={6} d="rt" />
        <Bracket x={194} y={6} d="lt" />
        <Bracket x={6} y={354} d="rb" />
        <Bracket x={194} y={354} d="lb" />
      </svg>
    </div>
  )
}

function Bracket({ x, y, d }: { x: number; y: number; d: 'rt' | 'lt' | 'rb' | 'lb' }) {
  const len = 18
  const stroke = '#fbf8f3'
  const sw = 1.5
  switch (d) {
    case 'rt': return <><line x1={x} y1={y} x2={x + len} y2={y} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /><line x1={x} y1={y} x2={x} y2={y + len} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /></>
    case 'lt': return <><line x1={x} y1={y} x2={x - len} y2={y} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /><line x1={x} y1={y} x2={x} y2={y + len} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /></>
    case 'rb': return <><line x1={x} y1={y} x2={x + len} y2={y} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /><line x1={x} y1={y} x2={x} y2={y - len} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /></>
    case 'lb': return <><line x1={x} y1={y} x2={x - len} y2={y} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /><line x1={x} y1={y} x2={x} y2={y - len} stroke={stroke} strokeWidth={sw} strokeOpacity="0.7" /></>
  }
}

function BodyGuide({ bodyType }: { bodyType: BodyType }) {
  // Drawn relative to viewBox 200x360; head at top, feet at bottom
  const stroke = 'url(#poseStroke)'
  const sw = 1.5
  // Define shoulder, waist, hip widths per body type
  const dims: Record<BodyType, { shoulder: number; waist: number; hip: number }> = {
    rectangle: { shoulder: 62, waist: 58, hip: 62 },
    hourglass: { shoulder: 68, waist: 44, hip: 68 },
    pear: { shoulder: 54, waist: 50, hip: 72 },
    apple: { shoulder: 60, waist: 66, hip: 58 },
    'inverted-triangle': { shoulder: 76, waist: 56, hip: 56 },
    athletic: { shoulder: 70, waist: 52, hip: 62 },
    slim: { shoulder: 50, waist: 40, hip: 50 },
    plus: { shoulder: 72, waist: 70, hip: 76 }
  }
  const d = dims[bodyType]
  const cx = 100
  const shoulderY = 100
  const waistY = 180
  const hipY = 230
  const feetY = 340

  return (
    <g fill="none" stroke={stroke} strokeWidth={sw} strokeDasharray="4 4">
      {/* torso left edge */}
      <path d={`M${cx - d.shoulder} ${shoulderY} Q${cx - d.waist - 2} ${(shoulderY + waistY)/2} ${cx - d.waist} ${waistY} Q${cx - d.hip - 2} ${(waistY + hipY)/2} ${cx - d.hip} ${hipY}`} />
      {/* torso right edge */}
      <path d={`M${cx + d.shoulder} ${shoulderY} Q${cx + d.waist + 2} ${(shoulderY + waistY)/2} ${cx + d.waist} ${waistY} Q${cx + d.hip + 2} ${(waistY + hipY)/2} ${cx + d.hip} ${hipY}`} />
      {/* hips to feet (legs) */}
      <path d={`M${cx - d.hip} ${hipY} Q${cx - 24} ${(hipY + feetY)/2} ${cx - 18} ${feetY}`} />
      <path d={`M${cx + d.hip} ${hipY} Q${cx + 24} ${(hipY + feetY)/2} ${cx + 18} ${feetY}`} />
      {/* inseam */}
      <line x1={cx} y1={hipY} x2={cx} y2={feetY} strokeDasharray="2 6" strokeOpacity="0.4" />
      {/* shoulder line */}
      <line x1={cx - d.shoulder} y1={shoulderY} x2={cx + d.shoulder} y2={shoulderY} strokeDasharray="2 5" strokeOpacity="0.5" />
      {/* arms */}
      <path d={`M${cx - d.shoulder} ${shoulderY} Q${cx - d.shoulder - 18} ${shoulderY + 70} ${cx - d.waist - 8} ${waistY + 30}`} strokeOpacity="0.7" />
      <path d={`M${cx + d.shoulder} ${shoulderY} Q${cx + d.shoulder + 18} ${shoulderY + 70} ${cx + d.waist + 8} ${waistY + 30}`} strokeOpacity="0.7" />
    </g>
  )
}

function TryOnPicker({ onClose, onPick, onClear }: { onClose: () => void; onPick: (url: string) => void; onClear: () => void }) {
  const { user } = useAuth()
  const wardrobe = user ? storage.get<WardrobeItem[]>(`wardrobe:${user.id}`, []) : []
  const [tab, setTab] = useState<'wardrobe' | 'katalog'>(wardrobe.length ? 'wardrobe' : 'katalog')

  return (
    <div className="fixed inset-0 z-[70] bg-ink-900/90 backdrop-blur-sm flex items-end" onClick={onClose}>
      <div className="w-full bg-cream-50 rounded-t-3xl text-ink-900 animate-slide-up max-h-[75vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="px-5 pt-3">
          <div className="w-10 h-1 rounded-full bg-ink-200 mx-auto" />
          <h3 className="font-display text-xl mt-3 text-center">Pilih outfit untuk try-on</h3>
          <div className="flex gap-1 mt-3 bg-cream-100 p-1 rounded-full">
            <button onClick={() => setTab('wardrobe')} className={`flex-1 py-2 rounded-full text-sm font-medium ${tab === 'wardrobe' ? 'bg-ink-900 text-cream-50' : 'text-ink-600'}`}>
              Lemari ({wardrobe.length})
            </button>
            <button onClick={() => setTab('katalog')} className={`flex-1 py-2 rounded-full text-sm font-medium ${tab === 'katalog' ? 'bg-ink-900 text-cream-50' : 'text-ink-600'}`}>
              Katalog toko
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {tab === 'wardrobe' ? (
            wardrobe.length === 0 ? (
              <div className="text-center py-8 text-sm text-ink-400">
                Lemarimu masih kosong. Buka tab Lemari di pojok atas untuk upload baju pribadi.
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                {wardrobe.map(w => (
                  <button key={w.id} onClick={() => onPick(w.imageDataUrl)} className="aspect-square rounded-xl overflow-hidden border border-ink-100 bg-cream-100">
                    <img src={w.imageDataUrl} alt={w.label} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {PRODUCTS.slice(0, 24).map(p => (
                <button key={p.id} onClick={() => onPick(p.imageUrl)} className="aspect-square rounded-xl overflow-hidden border border-ink-100 bg-cream-100">
                  <img src={p.imageUrl} alt={p.name} loading="lazy" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="p-4 border-t border-ink-100 pb-safe">
          <button onClick={onClear} className="btn-ghost w-full border border-ink-200">Hapus overlay</button>
        </div>
      </div>
    </div>
  )
}

function CapturePreview({ url, onClose, onDownload, onShare }: { url: string; onClose: () => void; onDownload: () => void; onShare: () => void }) {
  return (
    <div className="fixed inset-0 z-[80] bg-ink-900/95 flex flex-col">
      <div className="flex-1 flex items-center justify-center p-6">
        <img src={url} alt="Capture" className="max-w-full max-h-full rounded-2xl shadow-2xl" />
      </div>
      <div className="pb-safe px-6 py-4 flex gap-3">
        <button onClick={onClose} className="flex-1 bg-cream-50/10 text-cream-50 border border-cream-50/20 py-3 rounded-full font-medium">Foto ulang</button>
        <button onClick={onShare} className="flex-1 bg-cream-50/10 text-cream-50 border border-cream-50/20 py-3 rounded-full font-medium">Share</button>
        <button onClick={onDownload} className="flex-1 bg-cream-50 text-ink-900 py-3 rounded-full font-medium">Simpan</button>
      </div>
    </div>
  )
}
