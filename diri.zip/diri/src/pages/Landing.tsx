import { Link } from 'react-router-dom'
import { LogoMark } from '@/components/Splash'

export function Landing() {
  return (
    <div className="min-h-screen bg-cream-100 flex flex-col">
      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 text-center relative overflow-hidden">
        {/* Decorative grain & circles */}
        <div className="absolute inset-0 opacity-[0.04]" style={{
          backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence baseFrequency=\'0.9\'/%3E%3C/filter%3E%3Crect width=\'200\' height=\'200\' filter=\'url(%23n)\'/%3E%3C/svg%3E")'
        }} />
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-clay-400/20 blur-3xl" />
        <div className="absolute -bottom-40 -left-20 w-80 h-80 rounded-full bg-ink-900/5 blur-3xl" />

        <div className="relative z-10 animate-slide-up">
          <LogoMark size={72} />
          <h1 className="font-display text-6xl md:text-7xl tracking-[0.18em] mt-6 font-light">DIRI</h1>
          <p className="font-display italic text-lg md:text-xl text-ink-600 mt-3 max-w-md text-balance">
            menata diri, bahagia hari ini
          </p>
          <p className="font-sans text-ink-400 mt-8 max-w-md text-balance leading-relaxed">
            Stylist personal yang mengerti bentuk badan, warna kulit, dan vibe-mu.
            Dari padu padan harian sampai outfit acara penting — semua di satu tempat.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 mt-10 w-full max-w-sm mx-auto">
            <Link to="/register" className="btn-primary flex-1 text-center">
              Mulai sekarang
            </Link>
            <Link to="/login" className="btn-ghost flex-1 text-center border border-ink-200">
              Sudah punya akun
            </Link>
          </div>
        </div>
      </div>

      <footer className="text-center py-6 text-xs tracking-widest text-ink-400 uppercase">
        <span>© DIRI · Indonesia</span>
      </footer>
    </div>
  )
}
