import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { LogoMark } from '@/components/Splash'
import { hasApiKey } from '@/lib/ai'

const STYLE_OPTIONS = ['minimalis', 'streetwear', 'klasik', 'feminin', 'edgy', 'sporty', 'vintage', 'bohemian', 'preppy', 'modest', 'smart-casual', 'glam']
const COLOR_OPTIONS = ['hitam', 'putih', 'krem', 'cokelat', 'navy', 'abu', 'olive', 'mocca', 'dusty pink', 'merah', 'mustard', 'sage', 'lavender', 'pastel']

export function Profile() {
  const { user, profile, logout, updateProfile } = useAuth()
  const nav = useNavigate()
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(profile)

  function save() {
    updateProfile(draft)
    setEditing(false)
  }
  function cancel() {
    setDraft(profile)
    setEditing(false)
  }

  function toggleArr(field: 'stylePreferences' | 'colorPreferences', val: string) {
    const cur = draft[field]
    setDraft({ ...draft, [field]: cur.includes(val) ? cur.filter(x => x !== val) : [...cur, val] })
  }

  return (
    <div className="max-w-2xl mx-auto px-5 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-3xl font-light">Profil</h1>
        {!editing ? (
          <button onClick={() => setEditing(true)} className="text-xs uppercase tracking-widest text-ink-600 hover:text-ink-900">
            Edit
          </button>
        ) : (
          <div className="flex gap-2">
            <button onClick={cancel} className="text-xs uppercase tracking-widest text-ink-400">Batal</button>
            <button onClick={save} className="text-xs uppercase tracking-widest text-ink-900 font-medium">Simpan</button>
          </div>
        )}
      </div>

      {/* User card */}
      <div className="card p-5 mb-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-ink-900 flex items-center justify-center text-cream-50 font-display text-xl">
            {user?.name?.[0]?.toUpperCase() ?? '?'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-medium truncate">{user?.name}</div>
            <div className="text-xs text-ink-400 truncate">{user?.email}</div>
          </div>
        </div>
      </div>

      {/* Fisik */}
      <Section title="Fisik">
        <Row label="Gender" value={profile.gender ?? '—'} />
        <Row label="Usia" value={profile.age ? `${profile.age} tahun` : '—'} />
        <Row label="Tinggi" value={profile.heightCm ? `${profile.heightCm} cm` : '—'} />
        <Row label="Berat" value={profile.weightKg ? `${profile.weightKg} kg` : '—'} />
        <Row label="Bentuk tubuh" value={profile.bodyType ?? '—'} />
        <Row label="Skintone" value={profile.skintone ?? '—'} />
        <Row label="Undertone" value={profile.undertone ?? '—'} />
        <Row label="Head style" value={profile.headStyle ?? '—'} />
      </Section>

      {/* Preferensi */}
      <Section title="Preferensi gaya">
        {editing ? (
          <>
            <FieldLabel>Style</FieldLabel>
            <ChipGroup options={STYLE_OPTIONS} values={draft.stylePreferences} onToggle={v => toggleArr('stylePreferences', v)} />
            <FieldLabel className="mt-3">Warna favorit</FieldLabel>
            <ChipGroup options={COLOR_OPTIONS} values={draft.colorPreferences} onToggle={v => toggleArr('colorPreferences', v)} />
          </>
        ) : (
          <>
            <Row label="Style" value={profile.stylePreferences.join(', ') || '—'} />
            <Row label="Lifestyle" value={profile.lifestylePreferences.join(', ') || '—'} />
            <Row label="Warna favorit" value={profile.colorPreferences.join(', ') || '—'} />
            <Row label="Brand favorit" value={profile.preferredBrands.join(', ') || '—'} />
            <Row label="Budget" value={profile.budget ?? '—'} />
            <Row label="Profesi" value={profile.occupationOrLifestyle || '—'} />
          </>
        )}
      </Section>

      <button
        onClick={() => nav('/onboarding')}
        className="w-full mt-4 p-4 rounded-2xl border border-ink-200 bg-cream-50 text-left hover:border-ink-400 transition"
      >
        <div className="font-medium text-sm">Ulang onboarding</div>
        <div className="text-xs text-ink-400 mt-0.5">Setel ulang semua preferensi dari awal.</div>
      </button>

      <div className="card p-5 mt-6">
        <div className="flex items-center gap-3">
          <LogoMark size={28} />
          <div className="flex-1">
            <div className="font-display text-base">DIRI v0.1</div>
            <div className="text-[11px] text-ink-400">
              {hasApiKey() ? 'AI mode: Claude API aktif' : 'AI mode: offline (rule-based)'}
            </div>
          </div>
        </div>
        <p className="text-[11px] text-ink-400 mt-3 leading-relaxed">
          Semua data tersimpan lokal di browser kamu. Untuk dipindah ke device lain, kamu perlu daftar ulang dan isi profil di sana.
        </p>
      </div>

      <button onClick={() => { logout(); nav('/', { replace: true }) }} className="w-full mt-6 p-3.5 rounded-full border border-clay-400 text-clay-600 font-medium hover:bg-clay-400/5">
        Keluar dari akun
      </button>

      <div className="h-8" />
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <h2 className="text-xs uppercase tracking-widest text-ink-400 mb-2 px-1">{title}</h2>
      <div className="card divide-y divide-ink-100">{children}</div>
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="px-4 py-3 flex items-center justify-between gap-3">
      <span className="text-xs text-ink-400">{label}</span>
      <span className="text-sm text-ink-900 text-right truncate max-w-[60%]">{value}</span>
    </div>
  )
}

function FieldLabel({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`text-[11px] uppercase tracking-widest text-ink-400 px-4 pt-3 pb-2 ${className}`}>{children}</div>
}

function ChipGroup({ options, values, onToggle }: { options: string[]; values: string[]; onToggle: (v: string) => void }) {
  return (
    <div className="px-4 pb-3 flex flex-wrap gap-2">
      {options.map(o => (
        <button
          key={o}
          type="button"
          onClick={() => onToggle(o)}
          className={`px-3 py-1.5 rounded-full text-xs font-medium border ${
            values.includes(o)
              ? 'bg-ink-900 text-cream-50 border-ink-900'
              : 'bg-cream-50 border-ink-200 text-ink-600'
          }`}
        >
          {o}
        </button>
      ))}
    </div>
  )
}
