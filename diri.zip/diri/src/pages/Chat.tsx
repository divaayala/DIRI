import { useEffect, useRef, useState } from 'react'
import { useAuth } from '@/context/AuthContext'
import { storage, uid } from '@/lib/storage'
import { askStylist, hasApiKey } from '@/lib/ai'
import { findProductById, formatRupiah, buildMarketplaceUrl } from '@/data/products'
import type { ChatMessage, OutfitRecommendation, Product } from '@/types'
import { ProductDetail } from './Search'

const SUGGESTIONS = [
  'Outfit untuk meeting penting di kantor',
  'Bingung tema kemerdekaan, kasih ide dong',
  'Kondangan outdoor sore hari, modest',
  'Date night di rooftop café',
  'Nongkrong kasual tapi tetap stylish',
  'Pakaian olahraga ke gym yang fashionable'
]

export function Chat() {
  const { user, profile } = useAuth()
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [thinking, setThinking] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!user) return
    const saved = storage.get<ChatMessage[]>(`chat:${user.id}`, [])
    setMessages(saved)
  }, [user])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, thinking])

  function persist(msgs: ChatMessage[]) {
    if (!user) return
    storage.set(`chat:${user.id}`, msgs.slice(-50))
  }

  async function send(text: string) {
    const content = text.trim()
    if (!content || thinking) return
    setInput('')
    const userMsg: ChatMessage = { id: uid('m_'), role: 'user', content, timestamp: new Date().toISOString() }
    const newMsgs = [...messages, userMsg]
    setMessages(newMsgs)
    persist(newMsgs)
    setThinking(true)

    try {
      const history = newMsgs.map(m => ({ role: m.role, content: m.content }))
      const result = await askStylist(content, profile, history)
      const aiMsg: ChatMessage = {
        id: uid('m_'),
        role: 'assistant',
        content: result.reply,
        outfit: result.outfit ? { ...result.outfit, profileWarnings: result.profileWarnings } : undefined,
        timestamp: new Date().toISOString()
      }
      const finalMsgs = [...newMsgs, aiMsg]
      setMessages(finalMsgs)
      persist(finalMsgs)
    } catch (e) {
      const errMsg: ChatMessage = {
        id: uid('m_'),
        role: 'assistant',
        content: 'Aduh, lagi ada gangguan koneksi. Coba lagi sebentar ya.',
        timestamp: new Date().toISOString()
      }
      setMessages([...newMsgs, errMsg])
      persist([...newMsgs, errMsg])
    } finally {
      setThinking(false)
    }
  }

  function clearChat() {
    if (!confirm('Hapus seluruh percakapan?')) return
    setMessages([])
    if (user) storage.remove(`chat:${user.id}`)
  }

  return (
    <div className="max-w-3xl mx-auto h-[calc(100vh-14rem)] md:h-[calc(100vh-12rem)] flex flex-col px-4 md:px-6">
      <div className="flex items-center justify-between py-4">
        <div>
          <h1 className="font-display text-2xl font-light">Stylist AI</h1>
          <p className="text-xs text-ink-400">
            {hasApiKey() ? 'Powered by Claude' : 'Mode offline (rule-based) — atur VITE_ANTHROPIC_API_KEY untuk full AI'}
          </p>
        </div>
        {messages.length > 0 && (
          <button onClick={clearChat} className="text-xs text-ink-400 hover:text-clay-600">Reset</button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-4 pb-4">
        {messages.length === 0 ? (
          <EmptyState onPick={send} profileComplete={profile.completed} />
        ) : (
          messages.map(m => (
            <MessageBubble key={m.id} msg={m} onProductClick={setSelectedProduct} />
          ))
        )}
        {thinking && (
          <div className="flex justify-start">
            <div className="bg-cream-50 border border-ink-100 rounded-3xl rounded-tl-md px-4 py-3 flex gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-ink-400 animate-pulse" />
              <span className="w-1.5 h-1.5 rounded-full bg-ink-400 animate-pulse" style={{ animationDelay: '0.2s' }} />
              <span className="w-1.5 h-1.5 rounded-full bg-ink-400 animate-pulse" style={{ animationDelay: '0.4s' }} />
            </div>
          </div>
        )}
      </div>

      <form onSubmit={e => { e.preventDefault(); send(input) }} className="sticky bottom-0 bg-cream-100 pt-2 pb-2">
        <div className="flex gap-2 items-end bg-cream-50 border border-ink-200 rounded-3xl p-1.5 focus-within:border-ink-600 transition-colors">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input) }
            }}
            placeholder="Tanya stylist-mu apa saja..."
            rows={1}
            className="flex-1 resize-none bg-transparent px-3 py-2.5 text-sm focus:outline-none max-h-32"
          />
          <button
            type="submit"
            disabled={!input.trim() || thinking}
            className="w-10 h-10 rounded-full bg-ink-900 text-cream-50 flex items-center justify-center disabled:opacity-30 transition active:scale-95"
            aria-label="Kirim"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M5 12l14-7-5 7 5 7-14-7z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" fill="currentColor" fillOpacity="0.2" />
            </svg>
          </button>
        </div>
      </form>

      {selectedProduct && <ProductDetail product={selectedProduct} onClose={() => setSelectedProduct(null)} />}
    </div>
  )
}

function EmptyState({ onPick, profileComplete }: { onPick: (s: string) => void; profileComplete: boolean }) {
  return (
    <div className="text-center py-8 max-w-md mx-auto animate-fade-in">
      <div className="w-14 h-14 rounded-2xl bg-ink-900 mx-auto flex items-center justify-center mb-4">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
          <path d="M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3z" stroke="#f5f1ea" strokeWidth="1.5" strokeLinejoin="round"/>
        </svg>
      </div>
      <h2 className="font-display text-2xl font-light">Halo, aku stylist-mu</h2>
      <p className="text-sm text-ink-400 mt-2 leading-relaxed">
        Ceritakan acara atau vibe yang kamu mau. Aku susunin look lengkap head-to-toe dari katalog DIRI.
      </p>
      {!profileComplete && (
        <p className="text-xs text-clay-600 bg-clay-400/10 px-3 py-2 rounded-2xl mt-4">
          Profilmu belum lengkap. Hasil bisa lebih akurat kalau diisi penuh.
        </p>
      )}
      <div className="flex flex-col gap-2 mt-6">
        {SUGGESTIONS.map(s => (
          <button
            key={s}
            onClick={() => onPick(s)}
            className="text-left text-sm bg-cream-50 border border-ink-200 hover:border-ink-400 rounded-2xl px-4 py-3 transition"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  )
}

function MessageBubble({ msg, onProductClick }: { msg: ChatMessage; onProductClick: (p: Product) => void }) {
  if (msg.role === 'user') {
    return (
      <div className="flex justify-end animate-slide-up">
        <div className="bg-ink-900 text-cream-50 rounded-3xl rounded-tr-md px-4 py-2.5 max-w-[80%] text-sm leading-relaxed">
          {msg.content}
        </div>
      </div>
    )
  }
  return (
    <div className="flex flex-col items-start gap-3 animate-slide-up">
      <div className="bg-cream-50 border border-ink-100 rounded-3xl rounded-tl-md px-4 py-3 max-w-[85%] text-sm leading-relaxed">
        {msg.content}
      </div>
      {msg.outfit && <OutfitCard outfit={msg.outfit} onProductClick={onProductClick} />}
    </div>
  )
}

function OutfitCard({ outfit, onProductClick }: { outfit: OutfitRecommendation; onProductClick: (p: Product) => void }) {
  const items = outfit.items.map(i => ({
    ...i,
    product: i.productId ? findProductById(i.productId) : undefined
  }))
  const total = items.reduce((s, i) => s + (i.product?.price ?? 0), 0)

  return (
    <div className="w-full max-w-[92%] bg-gradient-to-br from-cream-50 to-cream-100 rounded-3xl border border-ink-200 overflow-hidden">
      <div className="px-4 pt-4 pb-3 border-b border-ink-100">
        <p className="text-[11px] uppercase tracking-widest text-ink-400">{outfit.occasion}</p>
        <h3 className="font-display text-lg mt-0.5 leading-tight">{outfit.vibe}</h3>
      </div>

      {outfit.profileWarnings && outfit.profileWarnings.length > 0 && (
        <div className="px-4 py-2.5 bg-clay-400/10 text-[11px] text-clay-600 border-b border-ink-100">
          Hasil bisa lebih akurat jika kamu lengkapi: <span className="font-medium">{outfit.profileWarnings.join(', ')}</span>.
        </div>
      )}

      <div className="divide-y divide-ink-100">
        {items.map((i, idx) => (
          <div key={idx} className="p-3 flex gap-3 items-start">
            <div className="shrink-0">
              {i.product ? (
                <button onClick={() => onProductClick(i.product!)} className="block">
                  <img src={i.product.imageUrl} alt={i.product.name} loading="lazy" className="w-16 h-16 rounded-2xl object-cover bg-cream-100 border border-ink-100" />
                </button>
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-cream-100 border border-ink-100 flex items-center justify-center text-[10px] text-ink-400 text-center px-1 uppercase tracking-wider">
                  {i.role}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] uppercase tracking-widest text-ink-400">{i.role}</div>
              {i.product ? (
                <>
                  <div className="font-medium text-sm leading-tight mt-0.5 truncate">{i.product.name}</div>
                  <div className="text-[11px] text-ink-400 mt-0.5">{i.product.brand} · {formatRupiah(i.product.price)}</div>
                  <p className="text-[11px] text-ink-600 mt-1 leading-snug">{i.description}</p>
                  <a
                    href={buildMarketplaceUrl(i.product)}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="inline-block mt-1.5 text-[11px] font-medium text-ink-900 underline underline-offset-2 hover:text-ink-600"
                  >
                    Beli di {i.product.marketplace} →
                  </a>
                </>
              ) : (
                <>
                  <div className="font-medium text-sm leading-tight mt-0.5">Saran ideal</div>
                  <p className="text-[11px] text-ink-600 mt-1 leading-snug">{i.description}</p>
                  <p className="text-[10px] text-ink-400 mt-1 italic">Belum ada item persis di katalog — coba cari di tab Search.</p>
                </>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="px-4 py-3 border-t border-ink-100 bg-cream-50">
        <p className="text-[11px] text-ink-600 leading-relaxed">{outfit.stylingNotes}</p>
        {total > 0 && (
          <p className="text-xs font-medium mt-2 flex justify-between">
            <span>Estimasi total look</span>
            <span>{formatRupiah(total)}</span>
          </p>
        )}
      </div>
    </div>
  )
}
