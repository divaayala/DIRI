import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { LogoMark } from '@/components/Splash'

export function Login() {
  const { login } = useAuth()
  const nav = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setErr(null)
    const res = await login(email, password)
    setLoading(false)
    if (!res.ok) setErr(res.error ?? 'Login gagal.')
    else nav('/app/home', { replace: true })
  }

  return (
    <div className="min-h-screen bg-cream-100 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm">
        <Link to="/" className="flex flex-col items-center mb-8">
          <LogoMark size={48} />
          <span className="font-display tracking-[0.3em] text-sm mt-2">DIRI</span>
        </Link>

        <h1 className="font-display text-3xl text-center mb-2 font-light">Selamat datang kembali</h1>
        <p className="text-center text-ink-400 text-sm mb-8">Masuk untuk lanjut menata gaya harianmu.</p>

        <form onSubmit={onSubmit} className="space-y-3">
          <input
            type="email"
            className="input-field"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            autoComplete="email"
          />
          <input
            type="password"
            className="input-field"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
          {err && <p className="text-sm text-clay-600 px-2">{err}</p>}
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Memproses...' : 'Masuk'}
          </button>
        </form>

        <p className="text-center text-sm text-ink-400 mt-6">
          Belum punya akun?{' '}
          <Link to="/register" className="text-ink-900 underline underline-offset-4">
            Daftar di sini
          </Link>
        </p>
      </div>
    </div>
  )
}
