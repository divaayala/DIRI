import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { LogoMark } from '@/components/Splash'

export function Register() {
  const { register } = useAuth()
  const nav = useNavigate()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setErr(null)
    const res = await register(name, email, password)
    setLoading(false)
    if (!res.ok) setErr(res.error ?? 'Gagal daftar.')
    else nav('/onboarding', { replace: true })
  }

  return (
    <div className="min-h-screen bg-cream-100 flex items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm">
        <Link to="/" className="flex flex-col items-center mb-8">
          <LogoMark size={48} />
          <span className="font-display tracking-[0.3em] text-sm mt-2">DIRI</span>
        </Link>

        <h1 className="font-display text-3xl text-center mb-2 font-light">Buat akun baru</h1>
        <p className="text-center text-ink-400 text-sm mb-8">Mulai perjalananmu menemukan gaya yang paling kamu.</p>

        <form onSubmit={onSubmit} className="space-y-3">
          <input
            type="text"
            className="input-field"
            placeholder="Nama"
            value={name}
            onChange={e => setName(e.target.value)}
            required
            autoComplete="name"
          />
          <input
            type="email"
            className="input-field"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            autoComplete="email"
          />
          <input
            type="password"
            className="input-field"
            placeholder="Password (min. 6 karakter)"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
          />
          {err && <p className="text-sm text-clay-600 px-2">{err}</p>}
          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Memproses...' : 'Daftar'}
          </button>
        </form>

        <p className="text-center text-sm text-ink-400 mt-6">
          Sudah punya akun?{' '}
          <Link to="/login" className="text-ink-900 underline underline-offset-4">
            Masuk
          </Link>
        </p>
        <p className="text-center text-[11px] text-ink-400 mt-6 leading-relaxed">
          Akun & data disimpan lokal di browser kamu untuk MVP ini.
          Tidak ada data yang dikirim ke server pihak ketiga selain AI stylist.
        </p>
      </div>
    </div>
  )
}
