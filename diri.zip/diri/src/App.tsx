import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AuthProvider, useAuth } from '@/context/AuthContext'
import { Landing } from '@/pages/Landing'
import { Login } from '@/pages/Login'
import { Register } from '@/pages/Register'
import { Onboarding } from '@/pages/Onboarding'
import { AppShell } from '@/components/AppShell'
import { Home } from '@/pages/Home'
import { Search } from '@/pages/Search'
import { Camera } from '@/pages/Camera'
import { Chat } from '@/pages/Chat'
import { Profile } from '@/pages/Profile'
import { Wardrobe } from '@/pages/Wardrobe'
import { Splash } from '@/components/Splash'

function RequireAuth({ children }: { children: JSX.Element }) {
  const { user, loading } = useAuth()
  const location = useLocation()
  if (loading) return <Splash />
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />
  return children
}

function RequireProfile({ children }: { children: JSX.Element }) {
  const { profile, loading } = useAuth()
  if (loading) return <Splash />
  if (!profile.completed) return <Navigate to="/onboarding" replace />
  return children
}

function RedirectIfAuthed({ children }: { children: JSX.Element }) {
  const { user, profile, loading } = useAuth()
  if (loading) return <Splash />
  if (user && profile.completed) return <Navigate to="/app/home" replace />
  if (user && !profile.completed) return <Navigate to="/onboarding" replace />
  return children
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<RedirectIfAuthed><Landing /></RedirectIfAuthed>} />
        <Route path="/login" element={<RedirectIfAuthed><Login /></RedirectIfAuthed>} />
        <Route path="/register" element={<RedirectIfAuthed><Register /></RedirectIfAuthed>} />
        <Route path="/onboarding" element={<RequireAuth><Onboarding /></RequireAuth>} />

        <Route
          path="/app"
          element={
            <RequireAuth>
              <RequireProfile>
                <AppShell />
              </RequireProfile>
            </RequireAuth>
          }
        >
          <Route index element={<Navigate to="home" replace />} />
          <Route path="home" element={<Home />} />
          <Route path="search" element={<Search />} />
          <Route path="camera" element={<Camera />} />
          <Route path="chat" element={<Chat />} />
          <Route path="profile" element={<Profile />} />
          <Route path="wardrobe" element={<Wardrobe />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AuthProvider>
  )
}
